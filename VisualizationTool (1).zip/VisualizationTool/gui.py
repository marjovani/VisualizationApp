from math import log

import networkx as nx
from bokeh.models import Range1d, MultiLine, Circle, ColumnDataSource, CustomJS
from bokeh.models.graphs import from_networkx
from bokeh.layouts import gridplot, widgetbox
from bokeh.palettes import Inferno256, Viridis256, Greys256, Cividis256, viridis
from bokeh.plotting import figure
from bokeh.models.widgets import Button, Div, TextInput, Slider, Panel, RangeSlider, RadioButtonGroup, Tabs

from algorithms import dijkstra
from aggregator import Aggregator
from base_gui import BaseGUI
from custom_layouts import discrnd_layout
from dynamic_graph import DynamicGraph
from utils import interpolate_array, interpolate_dict


class GUI(BaseGUI):
    # Store currently used dynamic graph
    graph = None
    aggregated_graph = None

    # Currently selected timestamp
    timestamp = 1

    # Evaluate if we can compute a shortest path
    dijkstra = False

    #Evaluate if we are filtering the nodes
    filtering_nodes = False
    good_nodes = []

    #Is this the first drawing of the timeline?
    first_draw = True

    def __init__(self):
        # Setup the empty plot grid
        self.setup_empty_grid()

        # Default legend
        self.legend1 = Div(text="<h3>Legend (Inferno)</h3><img src='/VisualizationTool/static/inferno_palette.png'/>")
        self.palette1 = Inferno256
        self.legend2 = Div(text="<h3>Legend (Viridis)</h3><img src='/VisualizationTool/static/viridis_palette.png'/>")
        self.palette2 = Viridis256

        # Draw the page
        self.draw()

    def draw_timeline(self):
        """
        Plot type 1 - Timeline rappresenting edges of all timestamps
        """
        # Setup plot1
        timeline = figure(plot_width=1300, plot_height=450,
                          x_range=(-1.1, 1.1), y_range=(-1.1, 1.1))

        # Check if file selected
        if self.graph is not None:
            ts_orig = []
            ts_offset = []
            x = []
            y = []

            if self.first_draw:
                self.first_draw = False
                self.ts_range = (1, self.graph.max_timestamp)
                self.weight_range = (1, self.graph.max_weight)

            # If need to draw shortest path
            if self.dijkstra:
                # Get values from textinput
                source = int(self.first_node.value)
                target = int(self.second_node.value)

                # Store segments styles
                colors = []
                alphas = []
                width = []

                # True if we found at least one shorest path
                have_path = False

            # If we are filterning the nodes, process the input from the user
            # Store the given vertices in the list good_nodes
            if self.filtering_nodes:
                # Get value from textbox and clear it
                text_input = self.filter_nodes.value
                self.good_nodes.clear()

                # Get single nodes
                text_input = text_input.split(",")

                # For each range of nodes
                for i in text_input:
                    temp = i.split("-")
                    if len(temp) == 1 and int(temp[0]) not in self.good_nodes:
                        self.good_nodes.append(int(temp[0]))
                    elif len(temp) == 2:
                        if int(temp[1]) > int(temp[0]):
                            for k in range(int(temp[0]), int(temp[1])+1):
                                if k not in self.good_nodes:
                                    self.good_nodes.append(k)

            # For each timestamp
            for ts in self.graph.graphs:
                # Only plot timestamps in the specified range
                if ts >= self.ts_range[0] and ts <= self.ts_range[1]:
                    # If need to draw shortest path
                    if self.dijkstra:
                        path, weight = dijkstra(self.graph.get_graph(ts),
                                                source,
                                                target)
                        if path != []:
                            have_path = True

                    # For each edge
                    for u, v in self.graph.edges_for_ts(ts):
                        #Edge weights filtering
                        w = self.graph.graphs[ts][u][v]['weight']
                        if w >= self.weight_range[0] and w <= self.weight_range[1]:
                            if self.filtering_nodes:
                                if (u in self.good_nodes) and (v in self.good_nodes):
                                    x.append(u)
                                    y.append(v)
                                    ts_orig.append(ts)
                                    ts_offset.append(ts+50)
                            else:
                                x.append(u)
                                y.append(v)
                                ts_orig.append(ts)
                                ts_offset.append(ts+50)

                            if self.dijkstra:
                                # If need to draw shortest path
                                # If edge is part of shortest path
                                if (u in path) or (v in path):
                                    colors.append("red")
                                    width.append(4)
                                    alphas.append(1)
                                else:
                                    colors.append("grey")
                                    width.append(0.5)
                                    alphas.append(0.5)

            # If need to draw shortest path
            if self.dijkstra and have_path:
                data = {'ts_orig': ts_orig, 'ts_offset': ts_offset, 'x': x, 'y': y,
                        'colors': colors, 'width': width, 'alphas': alphas}

                # Parse data
                source = ColumnDataSource(data)

                # Append a segment
                timeline.segment(x0="ts_orig", y0="x", x1="ts_offset", y1="y",
                                 line_width="width", line_color="colors",
                                 line_alpha="alphas", source=source)
            else:
                data = {'ts_orig': ts_orig,
                        'ts_offset': ts_offset, 'x': x, 'y': y}

                # Parse data
                source = ColumnDataSource(data)

                # Append a segment
                timeline.segment(x0="ts_orig", y0="x", x1="ts_offset", y1="y",
                                 line_width=1, source=source)

            # Set new ranges
            timeline.x_range = Range1d(-50, max(ts_orig)+50)
            timeline.y_range = Range1d(-50, max(y)+50)

        return timeline

    def draw_graph(self, ts):
        """
        Plot type 2 - Node-link of selected timestamp
        """
        # Tooltips with node names
        Tooltips = [
            ("Node", "@name"),
            ("Neighbors", "@neighbors"),
        ]

        # Setup graph_plot
        graph_plot = figure(plot_width=650, plot_height=650,
                            x_range=(-1.1, 1.1), y_range=(-1.1, 1.1),
                            tooltips=Tooltips)

        if self.graph is not None and \
           0 <= ts < self.graph.max_timestamp:
            # Node/Edge attibutes
            node_neighbors = {}
            edge_color = {}
            edge_width = {}
            node_size = {}

            # Add edges color
            for start_node, end_node, data in self.graph.edges_for_ts(ts, data=True):
                # Add edge color and thickness based on weight
                edge_color[(start_node, end_node)] = log(data['weight'])
                edge_width[(start_node, end_node)] = log(data['weight'])
                # Compute neighbors number for each node
                node_neighbors[start_node] = sum(1 for node in self.graph.graphs[ts].neighbors(start_node))
                node_neighbors[end_node] = sum(1 for node in self.graph.graphs[ts].neighbors(end_node))

            if self.curr_metadata is not None:
                for node in self.graph.graphs[ts].nodes(data=True):
                    node_size[node[0]] = node[1]['h_depth']

            # Interpolate values in new ranges
            edge_width = interpolate_dict(edge_width, 1, 3)
            edge_color = interpolate_dict(edge_color, 255, 0)

            if self.curr_metadata is not None:
                node_color = interpolate_dict(node_size, 40, 200)
            else:
                node_color = interpolate_dict(node_neighbors, 50, 50)

            node_size = interpolate_dict(node_neighbors, 6, 20)

            # Assign each color of the palette to nodes
            for node in node_color:
                node_color[node] = self.palette2[int(node_color[node])]
            for edge in edge_color:
                edge_color[edge] = self.palette2[int(edge_color[edge])]

            # Alpha values for nodes/edges
            node_alpha = {i: 1 for i in range(1, max(node_color) + 1)}
            edge_alpha = {i: 1 for i in edge_color}

            # If we need do evalutate shortest path
            if self.dijkstra:
                # Get values from textinput
                source = int(self.first_node.value)
                target = int(self.second_node.value)

                path, weight = dijkstra(self.graph.get_graph(ts),
                                        source,
                                        target)

                if path != []:
                    # Alpha values for nodes/edges
                    node_alpha = {i: 0.25 for i in range(1, max(node_color) + 1)}
                    edge_alpha = {i: 0.25 for i in edge_color}

                    # Previous node to keep track of the path
                    prev_node = -1

                    # Highlight shortest path
                    for node in path:
                        # Highlight node of the path
                        node_alpha[node] = 1

                        # Highlight edge of the path
                        if prev_node != -1:
                            edge_alpha[(prev_node, node)] = 1

                        prev_node = node

            # Assign all the colors and sizes to nodes and edges
            nx.set_node_attributes(self.graph.graphs[ts],
                                   node_size,
                                   "node_size")

            nx.set_node_attributes(self.graph.graphs[ts],
                                   node_color,
                                   "node_color")

            nx.set_node_attributes(self.graph.graphs[ts],
                                   node_alpha,
                                   "node_alpha")

            nx.set_edge_attributes(self.graph.graphs[ts],
                                   edge_color,
                                   "edge_color")

            nx.set_edge_attributes(self.graph.graphs[ts],
                                   edge_width,
                                   "edge_width")

            nx.set_edge_attributes(self.graph.graphs[ts],
                                   edge_alpha,
                                   "edge_alpha")

            # Get graph and create desired layout
            conn_graph = self.graph.get_connected_graph(ts)
            conn_pos = nx.nx_agraph.pygraphviz_layout(conn_graph,
                                                      prog='sfdp',
                                                      args="-Goverlap=prism")

            # Compute new center of the plot
            max_pos = 0
            avg_pos = [0, 0]
            for node in conn_graph:
                avg_pos[0] += conn_pos[node][0]
                avg_pos[1] += conn_pos[node][1]

                # Get maximum distance from center
                if conn_pos[node][0] > max_pos:
                    max_pos = conn_pos[node][0]
                if conn_pos[node][1] > max_pos:
                    max_pos = conn_pos[node][1]

            # Some complex math
            avg_pos[0] /= len(conn_pos)
            avg_pos[1] /= len(conn_pos)
            max_pos /= 1.7

            # Change center
            offset = max_pos
            graph_plot.x_range = Range1d(avg_pos[0]-offset, avg_pos[0]+offset)
            graph_plot.y_range = Range1d(avg_pos[1]-offset, avg_pos[1]+offset)

            # Plot graph
            conn_renderer = from_networkx(conn_graph, conn_pos)

            # Add circle for each node
            conn_renderer.node_renderer.glyph = Circle(size="node_size",
                                                       fill_alpha="node_alpha",
                                                       line_alpha=0,
                                                       fill_color="node_color")

            # Add lines for edges
            conn_renderer.edge_renderer.glyph = MultiLine(line_alpha="edge_alpha",
                                                          line_color="edge_color",
                                                          line_width="edge_width")

            # Render Isolated nodes with a different layout
            isol_graph = self.graph.get_isolated_graph(ts)
            isol_renderer = from_networkx(isol_graph, discrnd_layout,
                                          scale=int(max_pos), framesize=100,
                                          center=avg_pos)

            # Add circle for each node
            isol_renderer.node_renderer.glyph = Circle(size=8,
                                                       fill_color="gray")

            # ! Add arrows to edges but REALLY SLOW
            # from bokeh.models import Arrow, VeeHead
            # for edge in self.graph.edges_for_ts(ts):
            #     x1 = conn_pos[edge[0]][0]
            #     y1 = conn_pos[edge[0]][1]
            #     x2 = conn_pos[edge[1]][0]
            #     y2 = conn_pos[edge[1]][1]

            #     graph_plot.add_layout(Arrow(end=VeeHead(size=6),
            #                                 x_start=x1, y_start=y1, x_end=x2, y_end=y2, line_alpha=0))

            # Add node names
            conn_renderer.node_renderer.data_source.data['name'] = list(conn_graph.nodes())
            isol_renderer.node_renderer.data_source.data['name'] = list(isol_graph.nodes())

            # Add neighbors for each node
            neighbors_list = []
            for node in self.graph.nodes_for_ts(ts):
                neighbors_list.append(list(self.graph.graphs[ts].neighbors(node)))

            conn_renderer.node_renderer.data_source.data['neighbors'] = list(neighbors_list)

            # Render it
            graph_plot.renderers.append(conn_renderer)
            graph_plot.renderers.append(isol_renderer)

        return graph_plot

    def draw_matrix(self):
        """
        Plot type 3 - Adjacency matrix of aggregated (over time) graph
        """
        matrix_plot = figure(plot_width=650, plot_height=650,
                             x_range=(-1.1, 1.1), y_range=(-1.1, 1.1))

        # If gragh selected
        if self.graph is not None:
            x = []
            y = []
            scaled_weights = []

            for start_node, end_node, data in self.aggregated_graph.edges(data=True):

                # Append nodes of given edge
                if self.filtering_nodes:
                    if (start_node in self.good_nodes) and (end_node in self.good_nodes):
                        scaled_weights.append(log(data['weight']))
                        x.append(start_node)
                        y.append(end_node)

                else:
                    x.append(start_node)
                    y.append(end_node)
                    scaled_weights.append(log(data['weight']))

            # Interpolate set of weight in colors
            colors = interpolate_array(scaled_weights, 0, 255)

            for i, value in enumerate(colors):
                colors[i] = self.palette1[int(value)]

            # Set ranges
            matrix_plot.x_range = Range1d(0, max(x))
            matrix_plot.y_range = Range1d(0, max(y))

            # Plot it
            matrix_plot.rect(x, y, color=colors, width=5, height=5)

        return matrix_plot

    def setup_grid(self):
        """
        Override of setup plot grid from BaseGUI
        """
        p1 = self.draw_timeline()
        p2 = self.draw_matrix()
        p3 = self.draw_graph(self.timestamp)

        self.grid = gridplot([[p1], [p2, p3]])

    def setup_left_widgetbox(self):
        """
        Init some example widgets for the left column
        Override this method with your own widgets
        """

        # Default values for widgets
        last_ts = 1

        end_ts = 2
        init_ts = 1
        final_ts = 2

        end_weight = 2
        init_weight = 1
        final_weight = 2

        n1 = "0"
        n2 = "0"
        n3 = "0"

        # Get values of the sliders from previous draws
        if self.graph is not None:
            last_ts = self.timestamp_slider.value

            end_ts = self.graph.max_timestamp
            init_ts = self.timestamp_range_slider.value[0]
            final_ts = self.timestamp_range_slider.value[1]

            end_weight = self.graph.max_weight
            init_weight = self.weight_range_slider.value[0]
            final_weight = self.weight_range_slider.value[1]

        # Titles
        filters_text = Div(text="<h3>Filters</h3>")
        dijkstra_text = Div(text="<h3>Dijkstra - Shorthest Path</h3>")
        palette1_text = Div(text="<h3>Palette selector:</h3>")
        palette2_text = Div(text="<h3>Palette selector:</h3>")
        # Timestamp slider
        self.timestamp_slider = Slider(start=1, end=end_ts, value=last_ts, step=1,
                                       title="Timestamp", callback_policy="mouseup")

        # Timestamp range slider
        self.timestamp_range_slider = RangeSlider(start=1, end=end_ts, value=(init_ts,final_ts),
                                  step=1, title="Timestamp range", callback_policy="mouseup")

        # Edge range slider
        self.weight_range_slider = RangeSlider(start=1, end=end_weight, value=(init_weight,final_weight),
                                  step=1, title="Edge weight range", callback_policy="mouseup")

        # Palette selection
        palette1_selector = RadioButtonGroup(labels=["Inferno", "Viridis", "Cividis", "Greys"])
        # palette_selector.on_change(self.palette_change_callback)
        palette1_selector.on_change('active', self.palette1_change_callback)
        # Palette selection
        palette2_selector = RadioButtonGroup(labels=["Inferno", "Viridis", "Cividis", "Greys"])
        # palette_selector.on_change(self.palette_change_callback)
        palette2_selector.on_change('active', self.palette2_change_callback)

        # Get value from textboxes in previous draws
        if self.graph is not None:
            n1 = str(self.first_node.value)
            n2 = str(self.second_node.value)
            n3 = str(self.filter_nodes.value)

        self.first_node = TextInput(value=n1, title="First node:")
        self.second_node = TextInput(value=n2, title="Second node:")
        self.filter_nodes = TextInput(value=n3, title="Provide the nodes to be present in the visualization:")
        do_shortest_path = Button(label="Show shortest path",
                                  button_type="primary")
        reset_shortest_path = Button(label="Reset",
                                     button_type="warning")
        do_filter_nodes = Button(label="Filter",
                                 button_type="primary")
        reset_nodes = Button(label="Reset", button_type="warning")

        # Set callbacks
        do_shortest_path.on_click(self.shortest_path_callback)
        reset_shortest_path.on_click(self.reset_shortest_path_callback)
        do_filter_nodes.on_click(self.filter_nodes_callback)
        reset_nodes.on_click(self.reset_nodes_callback)

        # ? Callback policy work on with CustomJS callbacks (for now)
        # self.timestamp_slider.on_change('value', self.timestamp_selected_callback)

        # ? Workaround using CustomJS
        source = ColumnDataSource(data=dict(value=[]))
        source.on_change('data', self.timestamp_selected_callback)

        self.timestamp_slider.callback = CustomJS(args=dict(source=source), code="""
            source.data = { value: [cb_obj.value] }
        """)


        source = ColumnDataSource(data=dict(value=[]))
        source.on_change('data', self.timestamp_range_selected_callback)

        self.timestamp_range_slider.callback = CustomJS(args=dict(source=source), code="""
            source.data = { value: cb_obj.value }
        """)


        source = ColumnDataSource(data=dict(value=[]))
        source.on_change('data', self.weight_range_selected_callback)

        self.weight_range_slider.callback = CustomJS(args=dict(source=source), code="""
            source.data = { value: cb_obj.value }
        """)

        # Example plot to fill space
        p1 = Div(text="<h2>Hi! Im a placeholder")
        p2 = Div(text="<h2>Hi! Im a placeholder")
        pNA = Div(text="<h2>Hi! Im a placeholder")

        # First tab - Overview
        tab_overview = Panel(child=widgetbox(filters_text,
                                             self.timestamp_range_slider,
                                             self.weight_range_slider,
                                             self.filter_nodes,
                                             do_filter_nodes,
                                             reset_nodes,
                                             dijkstra_text,
                                             self.first_node,
                                             self.second_node,
                                             do_shortest_path,
                                             reset_shortest_path),
                             title="Overview")

        # Second tab -1
        tab1 = Panel(child=widgetbox(palette1_text,
                                     palette1_selector,
                                     self.legend1), title="1")

        # Third tab - 2
        tab2 = Panel(child=widgetbox(self.timestamp_slider,
                                     palette2_text,
                                     palette2_selector,
                                     self.legend2), title="2")

        # Fourth tab - NA
        tab_na = Panel(child=pNA, title="NA")

        # Create tab menu
        tabs = Tabs(tabs=[tab_overview, tab1, tab2, tab_na])

        # Assign to left column
        self.left_widgetbox = tabs

    def shortest_path_callback(self):
        """
        Compute shortest path between two nodes
        using dijkstra algorithm
        """
        # Evalute if we can try to compute a shortest path
        self.dijkstra = self.graph is not None

        # Redraw the page
        self.draw()

    def reset_shortest_path_callback(self):
        """
        Reset visualization after shortest path
        """
        # Set to false and redraw the page
        self.dijkstra = False
        self.draw()

    def filter_nodes_callback(self):
        self.filtering_nodes = True
        self.draw()

    def reset_nodes_callback(self):
        self.filtering_nodes = False
        self.draw()

    def timestamp_selected_callback(self, attr, old, new):
        """
        Callback function for timestamp select using slider
        """
        # Get timestamp
        ts = new['value'][0]

        # Check if the selected timestamp exists in the graph
        if self.graph.is_valid_ts(ts):
            self.timestamp = ts
            self.draw()

    def timestamp_range_selected_callback(self, attr, old, new):
        """
        Callback function for timestamp range selection using range slider
        """
        # Get selected timestamps
        self.ts_range = new['value']
        self.draw()

    def weight_range_selected_callback(self, attr, old, new):
        """
        Callback function for edge weight range selection using range slider
        """
        # Get selected weights
        self.weight_range = new['value']
        self.draw()

    def open_dataset_button_callback(self, attr, old, new):
        """
        Callback function for when a new dataset is uploaded
        """
        # Get file name
        self.curr_dataset = new['file_name'][0]

        # Parse and save the contents
        self.parse_and_save(new['file_contents'][0],
                            self.dataset_store + self.curr_dataset)

        try:
            # Parse file and create a dynamic graph structure
            self.graph = DynamicGraph(self.dataset_store + self.curr_dataset)
            self.graph.make_graph()

            # Aggregate graph over time
            aggregator = Aggregator()
            self.aggregated_graph = aggregator.agg_time(
                self.graph.graphs, 1, self.graph.max_timestamp)
        except ValueError:
            self.graph = None

        # Reload GUI
        self.draw()

    def open_metadata_button_callback(self, attr, old, new):
        """
        Callback function for when a new dataset is uploaded
        """
        # Get file name
        self.curr_metadata = new['file_name'][0]

        # Parse and save the contents
        self.parse_and_save(new['file_contents'][0],
                            self.metadata_store + self.curr_metadata)

        try:
            # Parse metadata file and update graph
            self.graph.load_metadata_file(
                self.metadata_store + self.curr_metadata)

            # Reload GUI
            self.draw()
        except ValueError:
            pass

    def open_dataset_selection_callback(self, attr, old, new):
        """
        Callback function when a new dataset is selected
        """
        self.curr_dataset = new

        try:
            # Parse file and create a dynamic graph structure
            self.graph = DynamicGraph(self.dataset_store + self.curr_dataset)
            self.graph.make_graph()

            # Aggregate graph over time
            aggregator = Aggregator()
            self.aggregated_graph = aggregator.agg_time(
                self.graph.graphs, 1, self.graph.max_timestamp)
        except ValueError:
            self.graph = None

        # Update page
        self.draw()

    def open_metadata_selection_callback(self, attr, old, new):
        """
        Callback function when a new dataset is selected
        """
        self.curr_metadata = new

        try:
            # Parse metadata file and update graph
            self.graph.load_metadata_file(
                self.metadata_store + self.curr_metadata)

            # Reload GUI
            self.draw()
        except ValueError:
            pass

    def palette1_change_callback(self, attr, old, new):
        """
        Replace the global palette with chosen one
        """
        # Legends images path
        infero_palette = "/VisualizationTool/static/inferno_palette.png"
        viridis_palette = "/VisualizationTool/static/viridis_palette.png"
        cividis_palette = "/VisualizationTool/static/cividis_palette.png"
        greys_palette = "/VisualizationTool/static/greys_palette.png"

        # Default text
        legend1_text = "<h3>Legend ({0})</h3><img src='{1}'/>"

        if new == 0:
            legend1_text = legend1_text.format("Inferno", infero_palette)
            self.palette1 = Inferno256
        elif new == 1:
            legend1_text = legend1_text.format("Viridis", viridis_palette)
            self.palette1 = Viridis256
        elif new == 2:
            legend1_text = legend1_text.format("Cividis", cividis_palette)
            self.palette1 = Cividis256
        elif new == 3:
            legend1_text = legend1_text.format("Greys", greys_palette)
            self.palette1 = Greys256

        # Assign new legend
        self.legend1.text = legend1_text

        # Reload GUI
        self.draw()

    def palette2_change_callback(self, attr, old, new):
        """
        Replace the global palette with chosen one
        """
        # Legends images path
        infero_palette = "/VisualizationTool/static/inferno_palette.png"
        viridis_palette = "/VisualizationTool/static/viridis_palette.png"
        cividis_palette = "/VisualizationTool/static/cividis_palette.png"
        greys_palette = "/VisualizationTool/static/greys_palette.png"

        # Default text
        legend2_text = "<h3>Legend ({0})</h3><img src='{1}'/>"

        if new == 0:
            legend2_text = legend2_text.format("Inferno", infero_palette)
            self.palette2 = Inferno256
        elif new == 1:
            legend2_text = legend2_text.format("Viridis", viridis_palette)
            self.palette2 = Viridis256
        elif new == 2:
            legend2_text = legend2_text.format("Cividis", cividis_palette)
            self.palette2 = Cividis256
        elif new == 3:
            legend2_text = legend2_text.format("Greys", greys_palette)
            self.palette2 = Greys256

        # Assign new legend
        self.legend2.text = legend2_text

        # Reload GUI
        self.draw()
