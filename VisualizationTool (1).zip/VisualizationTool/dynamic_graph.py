import os
import matplotlib.pyplot as plt
import networkx as nx

from parse import parse_row


class DynamicGraph:
    # Store a graph for each timestamp
    graphs = {}

    # Store all the nodes that are not connected (in each timestamp)
    isolated_graphs = {}

    def __init__(self, data_file, metadata_file=None):
        """
        Constructor function

        Params:
        data_file: dynamic graph file to be parsed
        metadata_file (optional): metadata file for the graph
        """
        # Store filenames for later user
        self.data_file = data_file
        self.metadata_file = metadata_file

        # Get number of lines in hierarchy file (if possible)
        if metadata_file is not None:
            self.nodes_num = sum(1 for line in open(metadata_file))

        # Max timestamp
        self.max_timestamp = 0
        # Max hierarchy depth
        self.h_max = 0

        # Max weight
        self.max_weight = 0

        # Valid timestamps
        self.valid_timestamps = []

    def load_metadata_file(self, metadata_file):
        """
        Load and parse metadata previously missing
        """
        # Parse total number of nodes
        self.nodes_num = sum(1 for line in open(metadata_file))
        self.metadata_file = metadata_file

        # For each timestamp
        for ts in self.graphs:
            # Fill the graph with all nodes
            self.isolated_graphs[ts].add_nodes_from([i for i in range(1, self.nodes_num)])

            # Check which nodes are connected
            connected_nodes = self.graphs[ts].nodes()

            # Remove that nodes from the isolated graph
            self.isolated_graphs[ts].remove_nodes_from(connected_nodes)

        h_depth = []
        with open(self.metadata_file, "r") as f:
            for row in f.readlines():
                h_depth.append(row.count("/"))

        # Deepest tree of directories
        self.h_max = max(h_depth)

        for ts in self.graphs:
            for node in self.graphs[ts].nodes():
                self.graphs[ts].node[node]['h_depth'] = h_depth[node-1] #Array starts at 0, not at 1
            for node in self.isolated_graphs[ts].nodes():
                self.isolated_graphs[ts].node[node]['h_depth'] = h_depth[node-1] #Array starts at 0, not at 1

    def make_graph(self):
        """
        Parse the stored datafile and
        create a graph for each timestamp
        """
        # Open file (context manager)
        with open(self.data_file, "r") as f:
            # Start reading
            for row in f.readlines():
                # Parse the result
                result = parse_row(row)

                if result is not None:
                    # Split the results in
                    # ts = timestamp
                    # e1 = first edge
                    # e2 = second edge
                    # w = weight
                    ts, e1, e2, w = result

                    # Check if we already have an instance for given timestamp
                    if ts not in self.graphs:
                        # Create the main graph
                        self.graphs[ts] = nx.DiGraph(name="Timestamp {0}".format(ts))
                        self.isolated_graphs[ts] = nx.DiGraph(name="Timestamp {0}".format(ts))

                        # If we have metadata create the isolated nodes graph
                        if self.metadata_file is not None:
                            self.isolated_graphs[ts].add_nodes_from([(i, dict(name=i)) for i in range(1, self.nodes_num)])

                    # Append new edge
                    self.graphs[ts].add_node(e1, name=e1)
                    self.graphs[ts].add_node(e2, name=e2)
                    self.graphs[ts].add_edge(e1, e2, weight=w)

                    # Update max_weight
                    if w > self.max_weight:
                        self.max_weight = w

                    # If we have a metadafile where can get the info
                    if self.metadata_file is not None:
                        # If e1 is still in isolated graph, remove it
                        if e1 in self.isolated_graphs[ts].nodes():
                            self.isolated_graphs[ts].remove_node(e1)

                        # If e2 is still in isolated graph, remove it
                        if e2 in self.isolated_graphs[ts].nodes():
                            self.isolated_graphs[ts].remove_node(e2)

                    # Update max timestamp
                    if ts > self.max_timestamp:
                        self.max_timestamp = ts

                    # Add timestamp to valid collection
                    self.valid_timestamps.append(ts)

            # Check if something was done
            if self.graphs == {}:
                raise ValueError("Empty graph - File not in right format")

    def draw(self, filename, timestamp=1, display=True):
        """
        Draw the graph and saves it to `plots` dir with given filename.
        If not given, take the first time stamp of the array.
        If display is True shows it in a new windows.
        """
        if timestamp not in self.graphs:
            print("No graph for timestamp {0}".format(timestamp))
            return

        # Draw the graph
        nx.draw(self.graphs[timestamp], with_labels=True)

        # Check if directory exist
        if not os.path.isdir("plots"):
            os.mkdir("plots")

        # Save it
        plt.savefig("plots/{0}.png".format(filename))

        # Show us the magic
        if display:
            plt.show()

        # Clean the plot for next draws
        plt.clf()

    def info(self, timestamp=1, node=None):
        """
        Print info about the graph at given timestamp
        like number of nodes, edges, degree...

        Or print info about a particular node.
        """
        if timestamp in self.graphs:
            print(nx.info(self.graphs[timestamp], node))
        else:
            print("Empty timestamp")

    def get_connected_graph(self, ts):
        """
        Return the (connected) graph
        """
        return self.graphs[ts]

    def get_isolated_graph(self, ts):
        """
        Return the graph of nodes that are not connected
        (parsed from metadata file)
        """
        return self.isolated_graphs[ts]

    def is_valid_ts(self, ts):
        """
        Easy check if a timestamp exists in dynamic graph
        """
        return ts in self.valid_timestamps

    def get_graph(self, ts):
        """
        Access method for cleaner code
        """
        return self.graphs[ts]

    def nodes_for_ts(self, ts):
        """
        Access method for cleaner code
        """
        return self.graphs[ts].nodes()

    def edges_for_ts(self, ts, data=False):
        """
        Access method for cleaner code
        """
        return self.graphs[ts].edges(data=data)
