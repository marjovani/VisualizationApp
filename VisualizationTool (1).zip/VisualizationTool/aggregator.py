import networkx as nx


class Aggregator:
    # Constuctor function
    def __init__(self, filename=None):
        self.h_depth = []
        self.h_num = 0

        if filename is not None:
            # Count subdictories for each node
            with open(filename, "r") as f:
                for row in f.readlines():
                    self.h_depth.append(row.count("/"))
                    self.h_num += 1

                # Deepest tree of directories
                self.h_max = max(self.h_depth)

    def agg_nodes(self, graph, num):
        # Input validation
        if num not in range(1, self.h_max):
            print("Value outside of nodes ids range")
            return
        elif graph.number_of_nodes() != self.h_num:
            print("Discrepancy between node number and hierarchy file: {0} {1}".format(
                nx.number_of_nodes(graph), self.h_num))
            return

        # Init new aggregation graph
        agg_graph = nx.DiGraph()

        # Counter
        i = 1

        # While we have nodes
        while i < self.h_num:
            # Actual node in aggregate graph
            k = agg_graph.number_of_nodes() + 1
            agg_graph.add_node(k, agg_nodes=[])

            # Original nodes
            agg_graph.nodes[k]['agg_nodes'].append(i)

            # While node are to be aggregated
            if self.h_depth[i] > num:
                # While we have nodes
                while i < self.h_num:
                    # If nodes needs to be aggregated to first node
                    if self.h_depth[i] > num:
                        agg_graph.nodes[k]['agg_nodes'].append(i)
                        i += 1
                    else:
                        i += 1
                        break
            else:
                i += 1

        # Find start and nodes for each edge
        for edge in graph.edges(data=True):
            # Get start node
            for u in agg_graph.nodes():
                # If appear in aggregate graph
                if edge[0] in agg_graph.nodes[u]['agg_nodes']:
                    break

            # Get end node
            for v in agg_graph.nodes():
                # If appear in aggregate graph
                if edge[1] in agg_graph.nodes[v]['agg_nodes']:
                    break

            # If start and end node are diffrent
            if u != v:
                # If edge already exist
                if agg_graph.has_edge(u, v):
                    # Update weight
                    agg_graph[u][v]['weight'] += edge[2]['weight']
                else:
                    # Create a new edge from u to v
                    agg_graph.add_edge(u, v, weight=edge[2]['weight'])

        return agg_graph

    def agg_time(self, graphs, start_value, end_value):
        # Input validation
        if start_value > end_value:
            print("Timestamp difference must be postive")
            return

        # Init new aggregation graph
        agg_graph = nx.DiGraph()

        # Copy all nodes from original graph at timestamp 1
        for n in graphs[1].nodes():
            agg_graph.add_node(n)

        # For each graph where timestamp in in the range
        for i in range(start_value, end_value+1):
            # If graph exists
            if i in graphs:
                # For each edge at timestamp `i`
                for edge in graphs[i].edges(data=True):
                    u = edge[0]
                    v = edge[1]

                    # If edge was already in aggregate graph
                    if agg_graph.has_edge(u, v):
                        # Update weight
                        agg_graph[u][v]['weight'] += edge[2]['weight']
                    else:
                        # Add new edge from u to v
                        agg_graph.add_edge(u, v, weight=edge[2]['weight'])

        return agg_graph

    def multi_agg_nodes(self, graphs, num):
        if self.h_depth == [] and self.h_num == 0:
            raise ValueError("Not enough information to aggregate nodes")

        rv = {}

        # For each graph at all timestamps
        for ts in graphs:
            # Aggregate over nodes
            rv[ts] = self.agg_nodes(graphs[ts], num)

        return rv
