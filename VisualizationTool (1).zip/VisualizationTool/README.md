# Test visualization graph #

## Run ##

You can open the Visualization tool using:

    $ bokeh serve --show .

Inside the directory.
Make sure you have installed the requirements.

## Requirements ##

To run the script on your system you need to have a python3 environment installed. Make sure the commands `python3` and `pip` (`pip3` on some systems) work.

Steps:

1) Make sure the following are installed on your system:

    * Python3-setuptools, Python3-Dev and Python3-tkinter:
        ```bash
        # apt install -y python3-dev python3-setuptools python3-tk
        ```
    * Python3 wheel:
        ```bash
        # pip install wheel
        ```


2) Install Graphviz from http://graphviz.org/download/

3) Finally, install the required modules:
    ```bash
    # pip install -r requirements.txt
    ```
