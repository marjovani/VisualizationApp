from bokeh.models.widgets import Button, Div, TextInput, Slider, Panel, RangeSlider, RadioButtonGroup, Tabs, Dropdown
from bokeh.layouts import gridplot, widgetbox
from bokeh.palettes import Inferno256, Viridis256, Greys256, Cividis256, RdBu9

from dynamic_network.aggregator import Aggregator
from dynamic_network.dynamic_graph import DynamicGraph
from gui.base_gui import BaseGUI
from gui.utils import on_change
from plots.matrix import AdjacencyMatrix
from plots.nodelink import NodeLinkGraph
from static.statics import cividis_palette, greys_palette, infero_palette, viridis_palette
from plots.timeline import Timeline
import gui.dyntimeline_ds as dtl_ds

class GUI(BaseGUI):
    # Page title
    title = "VTG1"

    # Store currently used dynamic graph
    graph = None

    # Store the selected graph aggegated over time
    agg_graph = None

    def __init__(self):
        # Setup plots
        self.nodelink = NodeLinkGraph()
        self.timeline = Timeline()
        self.matrix = AdjacencyMatrix()

        # Setup the empty plot grid
        self.setup_empty_grid()

        # Default legend/palette for matrix
        self.matrix_legend = Div(text="<h3>Legend (Inferno)</h3>\
                                <img src='{0}'/>".format(infero_palette))

        # Default legend/palette for graph
        self.graph_legend = Div(text="<h3>Legend (Viridis)</h3>\
                                <img src='{0}'/>".format(viridis_palette))

    # Windows setup

    def setup_grid(self):
        """
        Create a grid with the defined plots
        """
        self.grid = gridplot([[self.timeline.plot],
                              [self.matrix.plot,
                               self.nodelink.plot]])

    def setup_left_widgetbox(self):
        """
        The left column is divided in 4 different
        tabs. Each one of them is generate by the
        corresponding get_tab_X function.
        """
        # Create each tab
        tab_overview = self.get_tab_overview()
        tab_matrix = self.get_tab_matrix()
        tab_nodelink = self.get_tab_nodelink()
        tab_timeline = self.get_tab_timeline()

        # Create tab menu
        self.tabs = Tabs(tabs=[tab_timeline, tab_matrix, tab_nodelink, tab_overview])

        # Assign to left column
        self.left_widgetbox = self.tabs

    # Tabs generation

    def get_tab_overview(self):
        """
        Initialize all the widgets and callbacks in the overview tab
        """

        # Reset Header
        reset_text = Div(text="<h3>Others</h3>")

        # Reset filters and shortest path
        reset_btn = Button(label="Reset", button_type="danger")
        reset_btn.on_click(self.reset_callback)

        # Create tab
        tab = Panel(title="Overview",
                    child=widgetbox(reset_text,
                                    reset_btn)
                    )

        return tab

    def get_tab_matrix(self):
        """
        Initialize all the widgets and callbacks in the first tab
        """
        # Filter for timestamp range
        self.timestamp_filter_matrix = RangeSlider(title="Timestamp range",
                                    start=1, end=2,
                                    value=(1, 2), step=1,
                                    callback_policy="mouseup")

        # Timestamp filter callback
        on_change(self.timestamp_filter_matrix, self.timestamp_filter_callback_matrix)


        # Filter for ranges of nodes
        self.node_filter_matrix = TextInput(title="Provide the nodes to be present\
                                             in the visualization:")

        # Filter for nodes button and callback
        filter_node_btn = Button(label="Filter", button_type="primary")
        filter_node_btn.on_click(self.filter_nodes_callback_matrix)

        filter_reset_btn = Button(label="Reset", button_type="warning")
        filter_reset_btn.on_click(self.filter_reset_callback)

        # Header text
        palette_text = Div(text="<h3>Palette selector:</h3>")

        # Palette selector
        palette_selector = RadioButtonGroup(labels=[
            "Inferno",
            "Viridis",
            "Cividis",
            "Greys"
        ], active=0)

        # Selector callback
        palette_selector.on_change('active', self.palette_change_callback)

        ordering_text = Div(text="<h3>Matrix Reordering</h3>")

        # TODO Make a slider for it
        # Matrix order button and callback
        order_btn = Button(label="Order", button_type="primary")
        order_btn.on_click(self.order_callback)

        reset_btn = Button(label="Reset", button_type="danger")
        reset_btn.on_click(self.reset_order_callback)

        # Create tab
        tab = Panel(title="Matrix",
                    child=widgetbox(
                        self.timestamp_filter_matrix,
                        self.node_filter_matrix,
                        filter_node_btn,
                        palette_text,
                        palette_selector,
                        self.matrix_legend,
                        ordering_text,
                        order_btn,
                        reset_btn)
                    )

        return tab

    def get_tab_nodelink(self):
        """
        Initialize all the widgets and callbacks in the second tab
        """
        # Select timestamp to be display on the graph
        self.timestamp_selector = Slider(title="Timestamp",
                                         start=1, end=2,
                                         value=1, step=1,
                                         callback_policy="mouseup")

        # Selector callback
        on_change(self.timestamp_selector,
                  self.timestamp_selected_callback)

        # List of possible configurations
        menu = [(str, str) for str in ["sfdp", "dot", "twopi"]]

        self.nodelink_prog_dropdown = Dropdown(label=menu[0][1],
                                             button_type="primary",
                                             menu=menu)
        self.nodelink_prog_dropdown.on_change('value', self.change_prog_nodelink_callback)

        # Header text
        palette_text = Div(text="<h3>Palette selector:</h3>")

        # Palette selector
        palette_selector = RadioButtonGroup(labels=[
            "Inferno",
            "Viridis",
            "Cividis",
            "Greys"
        ], active=1)

        # Selector callback
        palette_selector.on_change('active', self.palette_change_callback)

        # Header text
        dijkstra_text = Div(text="<h3>Dijkstra - Shorthest Path</h3>")

        # Search shortest path
        self.source_node_nodelink = TextInput(title="First node:", value="0")
        self.target_node_nodelink = TextInput(title="Second node:", value="0")

        # Shortest path button and callback
        shortest_path_btn = Button(label="Show shortest path",
                                   button_type="success")
        shortest_path_btn.on_click(self.shortest_path_callback_nodelink)

        # Create tab
        tab = Panel(child=widgetbox(
            self.timestamp_selector,
            self.nodelink_prog_dropdown,
            palette_text,
            palette_selector,
            dijkstra_text,
            self.source_node_nodelink,
            self.target_node_nodelink,
            shortest_path_btn,
            self.graph_legend),
            title="Nodelink")

        return tab

    def get_tab_timeline(self):
        """
        Initialize all the widgets and callbacks in the NA tab
        """
        # Header text
        filters_text = Div(text="<h3>Filters</h3>")

        # Filter for timestamp range
        self.timestamp_filter_timeline = RangeSlider(title="Timestamp range",
                                            start=1, end=2,
                                            value=(1, 2), step=1,
                                            callback_policy="mouseup")

        # Timestamp filter callback
        on_change(self.timestamp_filter_timeline, self.timestamp_filter_callback_timeline)

        # Filter for edge weight
        self.weight_filter = RangeSlider(title="Edge weight range",
                                         start=1, end=2,
                                         value=(1, 2), step=1,
                                         callback_policy="mouseup")

        # Weight filter callback
        on_change(self.weight_filter, self.weight_filter_callback)

        # Filter for ranges of nodes
        self.node_filter_timeline = TextInput(title="Provide the nodes to be present\
                                             in the visualization:")

        # Filter for nodes button and callback
        filter_node_btn = Button(label="Filter", button_type="primary")
        filter_node_btn.on_click(self.filter_nodes_callback_timeline)

        filter_reset_btn = Button(label="Reset", button_type="warning")
        filter_reset_btn.on_click(self.filter_reset_callback)

        # Header text
        datashader_text = Div(text="<h3>Datashader</h3>")

        # Button to Enable Datashader
        self.datashader_btn = Button(label="Enable Datashader", button_type="primary")
        self.datashader_btn.on_click(self.datashader_callback)

        # Header text
        dijkstra_text = Div(text="<h3>Dijkstra - Shorthest Path</h3>")

        # Search shortest path
        self.source_node_timeline = TextInput(title="First node:", value="0")
        self.target_node_timeline = TextInput(title="Second node:", value="0")

        # Shortest path button and callback
        shortest_path_btn = Button(label="Show shortest path",
                                   button_type="success")
        shortest_path_btn.on_click(self.shortest_path_callback_timeline)

        # Create tab
        tab = Panel(title="Timeline",
                    child=widgetbox(
                        filters_text,
                        self.timestamp_filter_timeline,
                        self.weight_filter,
                        self.node_filter_timeline,
                        filter_node_btn,
                        dijkstra_text,
                        self.source_node_timeline,
                        self.target_node_timeline,
                        shortest_path_btn,
                        datashader_text,
                        self.datashader_btn)
                    )

        return tab


    # Widgets callbacks

    def filter_nodes_callback_timeline(self):
        """
        Callback for the filter node button
        """
        # Store ranges where filter nodes
        node_ranges = []

        # Get raw input from the textbox
        raw_input = self.node_filter_timeline.value.split(',')

        # For each range of nodes
        for pair in raw_input:
            # Parse pair
            start = int(pair.split('-')[0])
            end = int(pair.split('-')[1])

            node_ranges.append(range(start, end))

        # Apply filter to timeline
        self.timeline.node_filter(self.graph, node_ranges)

    def filter_nodes_callback_matrix(self):
        """
        Callback for the filter node button
        """
        # Store ranges where filter nodes
        node_ranges = []

        # Get raw input from the textbox
        raw_input = self.node_filter_matrix.value.split(',')

        # For each range of nodes
        for pair in raw_input:
            # Parse pair
            start = int(pair.split('-')[0])
            end = int(pair.split('-')[1])

            node_ranges.append(range(start, end))

        # Apply filter to matrix
        self.matrix.node_filter(self.agg_graph, node_ranges)

    def filter_reset_callback(self):
        self.filtering_nodes = False
        self.draw()

    def timestamp_selected_callback(self, attr, old, new):
        """
        Callback function for timestamp slider
        """
        # Get timestamp
        ts = new['value'][0]

        # Check if the selected timestamp exists in the graph
        if self.graph.is_valid_ts(ts):
            self.nodelink.update(self.graph, ts)

    def datashader_callback(self):
        """
        Callback function for datashader
        """
        if self.graph is not None:
                if (self.datashader_btn.label == "Enable Datashader"):
                    self.timeline.datashader_set = dtl_ds.dynamicgraph_to_dataframe(self.graph)
                    self.timeline.dtl_ds_draw = dtl_ds.DynTimeLine_DS(self.timeline.datashader_set, self.timeline, palette=RdBu9)
                    self.datashader_btn.label = "Disable Datashader"
                else:
                    self.datashader_btn.label = "Enable Datashader"
                    self.timeline.dtl_ds_draw.datashader_clear()

    def timestamp_filter_callback_timeline(self, attr, old, new):
        """
        Callback function for timestamp range selection using range slider
        """
        # Get selected timestamps
        min_ts, max_ts = new['value'][0]

        self.timeline.timestamp_filter(self.graph, min_ts, max_ts)

    def timestamp_filter_callback_matrix(self, attr, old, new):
        """
        Callback function for timestamp range selection using range slider
        """
        # Get selected timestamps
        min_ts, max_ts = new['value'][0]

        # Aggregate graph over new timestamps
        aggregator = Aggregator()
        self.agg_graph = aggregator.agg_time(self.graph.graphs,
                                             int(min_ts),
                                             int(max_ts))

        # Update matrix plot
        self.matrix.update(self.agg_graph)

    def weight_filter_callback(self, attr, old, new):
        """
        Callback function for edge weight range selection using range slider
        """
        # Get selected weights
        min_weight, max_weight = new['value'][0]

        self.timeline.edge_weight_filter(self.graph,
                                         min_weight,
                                         max_weight)

    def shortest_path_callback_timeline(self):
        """
        Compute shortest path between two nodes
        using dijkstra algorithm
        """
        # Get values from textinput
        source = int(self.source_node_timeline.value)
        target = int(self.target_node_timeline.value)

        # Display shortest path
        self.timeline.shortest_path(self.graph, source, target)

    def shortest_path_callback_nodelink(self):
        """
        Compute shortest path between two nodes
        using dijkstra algorithm
        """
        # Get values from textinput
        source = int(self.source_node_nodelink.value)
        target = int(self.target_node_nodelink.value)

        # Display shortest path
        self.nodelink.shortest_path(self.graph, self.timestamp_selector.value,
                                    source, target)

    def order_callback(self):
        """
        Perform the matrix ordering operation
        """
        self.matrix.order(self.agg_graph)

    def reset_order_callback(self):
        """
        Reset the matrix after ordering
        """
        self.matrix.update(self.agg_graph)

    def palette_change_callback(self, attr, old, new):
        """
        Replace the global palette with chosen one
        """
        # Default text
        legend = "<h3>Legend ({0})</h3><img src='{1}'/>"

        if new == 0:
            legend = legend.format("Inferno", infero_palette)
            new_palette = Inferno256
        elif new == 1:
            legend = legend.format("Viridis", viridis_palette)
            new_palette = Viridis256
        elif new == 2:
            legend = legend.format("Cividis", cividis_palette)
            new_palette = Cividis256
        elif new == 3:
            legend = legend.format("Greys", greys_palette)
            new_palette = Greys256

        # Check which palette was selected and
        # from which tab
        if self.tabs.active == 1:
            # Assign new legend and new palette to matrix
            self.matrix_legend.text = legend
            self.matrix.update_palette(new_palette)

        elif self.tabs.active == 2:
            # Assign new legend and new palette to graph
            self.graph_legend.text = legend
            self.nodelink.update(self.graph,
                                 self.timestamp_selector.value,
                                 new_palette)

    def change_prog_nodelink_callback(self, attr, old, new):
        prog = new
        # Change dropdown label
        self.nodelink_prog_dropdown.label = prog
        # Set eventual attributes
        extra = ""
        if prog == 'sfdp':
            extra = "-Goverlap=prism"
        elif prog == 'dot':
            extra = "-Gratio=0.5"

        self.nodelink.prog = prog
        self.nodelink.prog_attrs = extra

        # Update nodelink with program
        self.nodelink.update(self.graph, self.timestamp_selector.value, self.nodelink.palette)

    def reset_callback(self):
        """
        Callback for the reset button.
        Reset all the filters and widgets
        """
        # Reset widgets
        self.timestamp_filter_timeline.value = (self.graph.min_ts,
                                       self.graph.max_ts)
        self.timestamp_filter_matrix.value = (self.graph.min_ts,
                                               self.graph.max_ts)
        self.weight_filter.value = (self.graph.min_weight,
                                    self.graph.max_weight)

        # Reset plots
        self.timeline.reset_filters()
        self.matrix.reset_filters(self.graph)
        self.nodelink.update(self.graph, self.timestamp_selector.value)

    def upload_dataset_callback(self, attr, old, new):
        """
        Callback function for when a new dataset is uploaded
        """
        # Get file name
        self.curr_dataset = new['file_name'][0]

        # Parse and save the contents
        self.parse_and_save(new['file_contents'][0],
                            self.dataset_store
                            + self.curr_dataset)

        # Load file and start plotting
        self.load_and_draw()
        # Update selected file in dropdown
        self.metadata_dropdown.label = self.curr_metadata[:-4]

    def upload_metadata_callback(self, attr, old, new):
        """
        Callback function for when a new dataset is uploaded
        """
        # Get file name
        self.curr_metadata = new['file_name'][0]

        # Parse and save the contents
        self.parse_and_save(new['file_contents'][0],
                            self.metadata_store + self.curr_metadata)

        try:
            # Parse metadata file and update graph
            self.graph.load_metadata_file(self.metadata_store
                                          + self.curr_metadata)

            # Update selected file in dropdown
            self.metadata_dropdown.label = self.curr_metadata[:-4]
        except ValueError:
            pass

        # Update nodelink visualization
        self.nodelink.update(self.graph,
                             self.timestamp_selector.value)

    def open_dataset_callback(self, attr, old, new):
        """
        Callback function when a new dataset is selected
        """

        # Set new file to be used
        self.curr_dataset = new
        # Load file and start plotting
        self.load_and_draw()

        # Update selected file in dropdown
        self.dataset_dropdown.label = self.curr_dataset[:-4]

    def open_metadata_callback(self, attr, old, new):
        """
        Callback function when a new dataset is selected
        """
        self.curr_metadata = new

        try:
            # Parse metadata file and update graph
            self.graph.load_metadata_file(self.metadata_store
                                          + self.curr_metadata)

            # Update selected file in dropdown
            self.metadata_dropdown.label = self.curr_metadata[:-4]
        except ValueError:
            pass

        # Update nodelink visualization
        self.nodelink.update(self.graph,
                             self.timestamp_selector.value)

    # Support functions

    def load_and_draw(self):
        """
        Try to parse and create a dynamic graph
        and aggreagate it over time.
        If succesful the display it on the plots and
        update the control widgets
        """
        try:
            # Parse file and create a dynamic graph structure
            self.graph = DynamicGraph(self.dataset_store + self.curr_dataset)
            self.graph.make_graph()

            # Aggregate graph over time
            aggregator = Aggregator()
            self.agg_graph = aggregator.agg_time(self.graph.graphs,
                                                 self.graph.min_ts,
                                                 self.graph.max_ts)
        except ValueError:
            self.graph = None

        # If file load went well
        if self.graph is not None:
            # Update timeline plot
            self.timeline.update(self.graph)
            # Setup widgets with new data
            self.timestamp_filter_timeline.start = self.graph.min_ts
            self.timestamp_filter_timeline.end = self.graph.max_ts
            self.timestamp_filter_timeline.value = (self.graph.min_ts,
                                           self.graph.max_ts)

            self.timestamp_filter_matrix.start = self.graph.min_ts
            self.timestamp_filter_matrix.end = self.graph.max_ts
            self.timestamp_filter_matrix.value = (self.graph.min_ts,
                                           self.graph.max_ts)

            self.weight_filter.start = self.graph.min_weight
            self.weight_filter.end = self.graph.max_weight
            self.weight_filter.value = (self.graph.min_weight,
                                        self.graph.max_weight)

            # Update matrix plot
            self.matrix.update(self.agg_graph)

            # Update graph plot
            self.nodelink.update(self.graph, self.graph.min_ts)

            # Setup nodelink widgets
            self.timestamp_selector.end = self.graph.max_ts
            self.timestamp_selector.value = self.graph.min_ts


    def debug_load(self, dataset=False, metadata=False):
        """
        Load default file and start drawing
        """
        if dataset:
            # Select file
            self.curr_dataset = "profile_semantic_trafo_final.txt"

            # Draw stuff
            self.load_and_draw()

            # Aggregate
            aggregator = Aggregator()
            self.agg_graph = aggregator.agg_time(self.graph.graphs,
                                                    self.graph.min_ts,
                                                    self.graph.max_ts)

            if metadata:
                # Select file
                self.curr_metadata = "profile_semantic_trafo_final_hierarchy.txt"

                # Parse metadata file and update graph
                self.graph.load_metadata_file(self.metadata_store
                                            + self.curr_metadata)
                # Update nodelink visualization
                self.nodelink.update(self.graph,
                                    self.timestamp_selector.value)
