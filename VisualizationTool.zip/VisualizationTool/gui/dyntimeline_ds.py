import math

import datashader as ds
import datashader.transfer_functions as tf
import pandas as pd
import numpy as np
from PIL import Image


class DynTimeLine_DS:
    def __init__(self, dataset, plot, lodf=6, palette=['lightblue', 'darkblue']):
        self.df = dataset
        self.p = plot.plot
        self.bokeh_tl = plot.bokeh_timeline
        self.image = None
        self.lodf = lodf
        self.palette = palette
        self.setup_plot()

    # Draws Datashader image from pandas DataFrame, including palette shading
    def draw_image(self, x_range, y_range, w, h):
        cvs = ds.Canvas(plot_width=w, plot_height=h, x_range=x_range, y_range=y_range)
        agg = cvs.line(self.df, 'x', 'y', ds.count())
        img = tf.shade(agg, cmap=self.palette)
        ret = img.to_bytesio()
        return ret

    # Draw image with full resolution, delete previous image
    def datashader_draw(self):
        self.bokeh_tl.visible = False
        image_raw = Image.open(self.draw_image((self.p.x_range.start, self.p.x_range.end), (self.p.y_range.start, self.p.y_range.end), self.p.plot_width, self.p.plot_height))
        image_raw = np.flipud(image_raw)
        image = self.p.image_rgba(image=[image_raw], x=self.p.x_range.start, y=self.p.y_range.start, dw=self.p.x_range.end - self.p.x_range.start, dh=self.p.y_range.end - self.p.y_range.start)
        self.image = image

    # Restore previous image
    def datashader_clear(self):
        self.bokeh_tl.visible = True
        if self.image:
            self.p.renderers.remove(self.image)
            self.image = None
        del self

    # Adds LOD Triggers and datashader image glyph to plot
    def setup_plot(self):
        self.p.lod_threshold = 0    # Always activate LOD
        self.p.lod_timeout = 200    # Lod timeout in milliseconds
        self.p.lod_factor = 1       # Keep all glyphs
        self.datashader_draw()      # First Drawing


def dynamicgraph_to_dataframe(graph):
    if graph is not None:
        df = []
        list = []
        # For each timestamp
        for ts in graph.graphs:
            # For each edge
            for u, v in graph.edges_for_ts(ts):
                list.append({'x':ts, 'y':u, 'val':1})
                list.append({'x':ts + 50, 'y':v, 'val':1})
                list.append({'x':math.nan, 'y':math.nan, 'val':math.nan})
        df.append(pd.DataFrame(list))
        df = pd.concat(df, ignore_index=True)
        return df
