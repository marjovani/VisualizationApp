from math import log

import networkx as nx
from bokeh.models import MultiLine, Circle
from bokeh.models.graphs import from_networkx
from bokeh.palettes import Viridis256
from bokeh.plotting import figure

from algorithms import dijkstra
from custom_layouts import discrnd_layout
from utils import interpolate_dict


class NodeLinkGraph:
    """
    This class manage all the functions/drawing and data
    of the Node-Link diagram
    """

    def __init__(self):
        """
        Initalize the plot
        """
        # Tooltips with node names and neighbors
        # TODO Fix tooltips don't showing
        tooltips = [
            ("Node", "@name"),
            ("Neighbors", "@neighbors"),
        ]

        # Contain style info about the graph
        self.data = {}

        # Setup plot
        self.plot = figure(plot_width=650, plot_height=650,
                           x_range=(-1.1, 1.1), y_range=(-1.1, 1.1),
                           tooltips=tooltips)

        # Used to reset plot on each render
        self.default_render = self.plot.renderers.copy()

        # Default palette
        self.palette = Viridis256

    def update(self, dynamic_graph, timestamp, palette=None):
        """
        Draw the graph of the dynamic_graph for the given timestamp
        """
        # Compute style attibutes
        self.__compute_colors(dynamic_graph.graphs[timestamp], palette)
        self.__make_graph(dynamic_graph, timestamp)

    def shortest_path(self, dynamic_graph, timestamp, source_node, target_node):
        # Compute shortest path
        path, _ = dijkstra(dynamic_graph.get_graph(timestamp),
                           source_node, target_node)

        # Alpha values for nodes/edges
        self.data['node_alpha'] = {
            i: 0.25
            for i in dynamic_graph.nodes_for_ts(timestamp)
        }

        self.data['edge_alpha'] = {
            i: 0.25
            for i in self.data['edge_color']
        }

        if path != []:
            # Previous node to keep track of the path
            prev_node = -1

            # Highlight shortest path
            for node in path:
                # Highlight node of the path
                self.data['node_alpha'][node] = 1

                # Highlight edge of the path
                if prev_node != -1:
                    self.data['edge_alpha'][(prev_node, node)] = 1

                prev_node = node

        self.__make_graph(dynamic_graph, timestamp)

    def __compute_colors(self, graph, palette=None):
        """
        Compute colors and size of the nodes/edges
        based on the weight/neighbors/hierarchy
        """
        # Node/Edge attibutes
        fields = ['neighbors', 'edge_color', 'edge_width', 'node_size']
        data = {field: {} for field in fields}

        # Check if palette was changed
        if palette is not None:
            self.palette = palette

        data['neighbors'] = {i: 0 for i in graph.nodes()}

        # Add edges color
        for u, v, edge_data in graph.edges(data=True):
            # Add edge color and thickness based on weight
            data['edge_color'][(u, v)] = log(edge_data['weight'])
            data['edge_width'][(u, v)] = log(edge_data['weight'])

            # Compute neighbors number for each node
            neighbors = graph.neighbors(u)
            data['neighbors'][u] = sum(1 for _ in neighbors)

            neighbors = graph.neighbors(v)
            data['neighbors'][v] = sum(1 for _ in neighbors)

        # if self.curr_metadata is not None:
        data['h_depth'] = {
            node[0]: node[1].get('h_depth', 0)
            for node in graph.nodes(data=True)
        }

        # Interpolate values in new ranges
        data['edge_width'] = interpolate_dict(data['edge_width'], 1, 3)
        data['edge_color'] = interpolate_dict(data['edge_color'], 0, 255)

        # TODO this was bugged changed it to neighbors
        data['node_size'] = interpolate_dict(data['neighbors'], 5, 20)

        # Check if h_depth have some value
        if max(data['h_depth'].values()) > 0:
            i = 'h_depth'
        else:
            i = 'neighbors'

        # Node color depends on h_depth if possible
        # neighbors number otherwise
        data['node_color'] = interpolate_dict(data[i], 0, 255)

        # Assign each color of the palette to nodes
        for node in data['node_color']:
            data['node_color'][node] = self.palette[int(
                data['node_color'][node])]

        for edge in data['edge_color']:
            data['edge_color'][edge] = self.palette[int(
                data['edge_color'][edge])]

        # Alpha values for nodes/edges
        data['node_alpha'] = {i: 1 for i in graph.nodes()}
        data['edge_alpha'] = {i: 1 for i in data['edge_color']}

        # Overwrite old graph style attributes
        self.data = data

    def __make_graph(self, dynamic_graph, timestamp):
        """
        Create a nice looking layout using external libraries
        and add previously computed style
        """
        # Assign all the colors and sizes to nodes and edges
        nx.set_node_attributes(dynamic_graph.graphs[timestamp],
                               self.data['node_size'], "node_size")

        nx.set_node_attributes(dynamic_graph.graphs[timestamp],
                               self.data['node_color'], "node_color")

        nx.set_node_attributes(dynamic_graph.graphs[timestamp],
                               self.data['node_alpha'], "node_alpha")

        nx.set_edge_attributes(dynamic_graph.graphs[timestamp],
                               self.data['edge_color'], "edge_color")

        nx.set_edge_attributes(dynamic_graph.graphs[timestamp],
                               self.data['edge_width'], "edge_width")

        nx.set_edge_attributes(dynamic_graph.graphs[timestamp],
                               self.data['edge_alpha'], "edge_alpha")

        # Get graph and create desired layout
        conn_graph = dynamic_graph.get_connected_graph(timestamp)
        conn_pos = nx.nx_agraph.pygraphviz_layout(conn_graph,
                                                  prog='sfdp',
                                                  args="-Goverlap=prism")

        # Compute new center of the plot
        max_pos = 0
        avg_pos = [0, 0]
        for node in conn_graph:
            avg_pos[0] += conn_pos[node][0]
            avg_pos[1] += conn_pos[node][1]

            # Get maximum distance from center
            if conn_pos[node][0] > max_pos:
                max_pos = conn_pos[node][0]
            if conn_pos[node][1] > max_pos:
                max_pos = conn_pos[node][1]

        # Some complex math
        avg_pos[0] /= len(conn_pos)
        avg_pos[1] /= len(conn_pos)
        max_pos /= 1.7

        # Plot graph
        conn_renderer = from_networkx(conn_graph, conn_pos)

        # Add circle for each node
        conn_renderer.node_renderer.glyph = Circle(size="node_size",
                                                        fill_alpha="node_alpha",
                                                        line_alpha=0,
                                                        fill_color="node_color")

        # Add lines for edges
        conn_renderer.edge_renderer.glyph = MultiLine(line_alpha="edge_alpha",
                                                      line_color="edge_color",
                                                      line_width="edge_width")

        # Render Isolated nodes with a different layout
        isol_graph = dynamic_graph.get_isolated_graph(timestamp)
        isol_renderer = from_networkx(isol_graph,
                                      discrnd_layout,
                                      scale=int(max_pos),
                                      framesize=100,
                                      center=avg_pos)

        # Add circle for each node
        isol_renderer.node_renderer.glyph = Circle(size=8,
                                                   fill_color="gray")

        # ! Add arrows to edges but REALLY SLOW
        # from bokeh.models import Arrow, VeeHead
        # for edge in self.graph.edges_for_ts(ts):
        #     x1 = conn_pos[edge[0]][0]
        #     y1 = conn_pos[edge[0]][1]
        #     x2 = conn_pos[edge[1]][0]
        #     y2 = conn_pos[edge[1]][1]

        #     self.plot.add_layout(Arrow(end=VeeHead(size=6),
        #                                 x_start=x1, y_start=y1, x_end=x2, y_end=y2, line_alpha=0))

        # Add node names
        conn_renderer.node_renderer.data_source.data['name'] = list(
            conn_graph.nodes())
        isol_renderer.node_renderer.data_source.data['name'] = list(
            isol_graph.nodes())

        # Add neighbors for each node
        neighbors_list = []
        for node in dynamic_graph.nodes_for_ts(timestamp):
            neighbors = dynamic_graph.neighbors_for_ts(node, timestamp)
            neighbors_list.append(list(neighbors))

        conn_renderer.node_renderer.data_source.data['neighbors'] = list(
            neighbors_list)

        # Reset plot to default
        self.plot.renderers = self.default_render

        # Change center
        self.plot.x_range.start = avg_pos[0] - max_pos
        self.plot.x_range.end = avg_pos[0] + max_pos
        self.plot.y_range.start = avg_pos[1] - max_pos
        self.plot.y_range.end = avg_pos[1] + max_pos

        # Render it
        self.plot.renderers.append(conn_renderer)
        self.plot.renderers.append(isol_renderer)