import random
from math import cos, sin

from numpy import pi


def discrnd_layout(G, scale, framesize, center):
    """
    Custom layout to display the outer nodes
    in a fancy circle form
    """
    isol_pos = dict([(node, [0, 0]) for node in G.nodes])

    for key in isol_pos:
        rng_angle = random.uniform(0, 2 * pi)
        rng_radius = random.randint(scale, scale + framesize)

        isol_pos[key][0] = rng_radius * cos(rng_angle) + center[0]
        isol_pos[key][1] = rng_radius * sin(rng_angle) + center[1]

    return isol_pos
