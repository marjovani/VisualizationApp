from bokeh.models import ColumnDataSource
from bokeh.plotting import figure

from dynamic_network.algorithms import dijkstra

class Timeline:
    """
    This class manage all the functions/drawing and data
    of the timeline plot
    """

    def __init__(self):
        """
        Initalize the plot and data
        """
        # Segments data to be displayed in the timeline plot
        self.data = ColumnDataSource(data=dict(x0=[], y0=[],
                                               x1=[], y1=[],
                                               widths=[],
                                               alphas=[],
                                               colors=[]))
        # Flags for filtering.
        self.visualstates = []

        # The actual timeline plot object
        self.plot = figure(plot_width=1300, plot_height=450,
                           x_range=(-1, 1), y_range=(-1, 1))

        # The segments to be displayed when self.timeline_data is changed
        self.bokeh_timeline = self.plot.segment("x0", "y0", "x1", "y1",
                                                line_width="widths",
                                                line_color="colors",
                                                line_alpha="alphas",
                                                source=self.data)

        self.datashader_set = None
        self.dtl_ds_draw = None

    def update_visuals(self, data):
        for i in range(1, len(self.visualstates)):
            _str = str(bin(self.visualstates[i]))
            _str = _str[3:]
            out = -1
            if (_str[0] == '1' or _str[1] == '1' or _str[2] == '1'):
                out = 1
            elif (_str[3] == '1'):
                out = 2
            elif (_str[4] == '1'):
                out = 3
            else:
                out = 0

            # Default active
            if out == 0:
                data['colors'][i] = '#0099FF'
                data['widths'][i] = 1
                data['alphas'][i] = 0.3
            # Default inactive
            elif out == 1:
                data['colors'][i] = 'lightgrey'
                data['widths'][i] = 0.5
                data['alphas'][i] = 0.5
            # Dijkstra highlight
            elif out == 3:
                data['colors'][i] = 'red'
                data['widths'][i] = 4
                data['alphas'][i] = 1
            # Dijkstra no highlight
            elif out == 2:
                data['colors'][i] = 'cadetblue'
                data['widths'][i] = 1
                data['alphas'][i] = 0.2

        return data

    def update(self, dynamic_graph, offset=50):
        """
        Given a dynamic_graph instance, parse it and display
        the edges of all timestamps
        """
        # Source data structure
        fields = ['x0', 'y0', 'x1', 'y1', 'colors', 'alphas', 'widths']
        data = {field: [] for field in fields}

        # For each graph
        for ts in dynamic_graph.graphs:
            # For each edge
            for u, v in dynamic_graph.edges_for_ts(ts):
                # Segment coordinates
                data['x0'].append(ts)
                data['y0'].append(u)
                data['x1'].append(ts+offset)
                data['y1'].append(v)

                data['colors'].append(-1)
                data['widths'].append(-1)
                data['alphas'].append(-1)

                # Segment properties
                self.visualstates.append(int('100000', 2))

        # Update the data source for the timeline
        self.data.data = self.update_visuals(data)

        # Update the ranges of the plot
        self.plot.x_range.start = min(data['x0']) - offset
        self.plot.x_range.end = max(data['x0']) + offset*2
        self.plot.y_range.start = min(data['y1']) - offset
        self.plot.y_range.end = max(data['y1']) + offset

    def timestamp_filter(self, dynamic_graph, min_ts, max_ts):
        """
        Filter out the edges outside the range (min_ts, max_ts) of timestamps
        """
        # Copy the data to be modified
        data = self.data.data.copy()

        # Node-timestamp reference
        node = 0

        # For each graph
        for ts in dynamic_graph.graphs:
            # For each edge
            for _, _ in dynamic_graph.edges_for_ts(ts):
                # If weight is in the range show it
                if min_ts <= ts <= max_ts:
                    self.visualstates[node] &= int('101111', 2)
                else:
                    self.visualstates[node] |= int('110000', 2)

                # Increment reference
                node += 1
        # Update the data source for the timeline
        self.data.data = self.update_visuals(data)

    def edge_weight_filter(self, dynamic_graph, min_weight, max_weight):
        """
        Filter out the edges outside the range (min_weight, max_weight)
        """
        # Copy the data to be modified
        data = self.data.data.copy()

        # Node-timestamp reference
        node = 0

        # For each graph
        for ts in dynamic_graph.graphs:
            # For each edge
            for _, _, edge_data in dynamic_graph.edges_for_ts(ts, data=True):
                # If weight is in the range show it
                if min_weight <= edge_data['weight'] <= max_weight:
                    self.visualstates[node] &= int('110111', 2)
                else:
                    self.visualstates[node] |= int('101000', 2)

                # Increment reference
                node += 1

        # Update the data source for the timeline
        self.data.data = self.update_visuals(data)

    def node_filter(self, dynamic_graph, node_ranges):
        """
        Filter out the nodes that are not in the defined set of ranges
        """
        # Copy the data to be modified
        data = self.data.data.copy()

        # Node-timestamp reference
        node = 0

        previous_range = []

        # For each graph
        for ts in dynamic_graph.graphs:
            # For each edge
            for start_node, end_node in dynamic_graph.edges_for_ts(ts):
                # If weight is in the range show it
                for node_range in node_ranges:
                    if start_node in node_range and end_node in node_range:
                        self.visualstates[node] &= int('111011', 2)
                        previous_range.append(node)
                    elif node in previous_range:
                        pass
                    else:
                        self.visualstates[node] |= int('100100', 2)

                # Increment reference
                node += 1

        # Update the data source for the timeline
        self.data.data = self.update_visuals(data)

    def shortest_path(self, dynamic_graph, source_node, target_node):
        """
        Compute the shortest path between source_node and target_node and
        display it on the plot
        """
        # Copy the data to be modified
        data = self.data.data.copy()

        # Color all the edges like `not in shortest path`
        for i in range(1, len(self.visualstates)):
            self.visualstates[i] |= int('100010', 2)

        # Node-timestamp reference
        node = 0

        # For each graph
        for ts in dynamic_graph.graphs:
            # Compute shortest path using Dijkstra algorithm
            path, _ = dijkstra(dynamic_graph.get_graph(ts),
                               source_node,
                               target_node)

            # If a path exists between source_node and target_node
            if path != []:
                # For each edge in given timestamp
                for u, v in dynamic_graph.edges_for_ts(ts):
                    # If edge is in path
                    if (u in path) and (v in path):
                        # Highlight edge
                        self.visualstates[node] |= int('100001', 2)
                        self.visualstates[node] &= int('111101', 2)

                    # Increment node
                    node += 1
            else:
                # Increment node by nodes skipped in this timestamp
                node += len(dynamic_graph.edges_for_ts(ts))

        # Replace old data
        self.data.data = self.update_visuals(data)

    def reset_filters(self, offset=50):
        """
        Reset all filters
        """
        # Copy the data to be modified
        data = self.data.data.copy()

        # Set default values
        length = len(self.visualstates)
        self.visualstates = [int('100000', 2) for i in range(1, length + 1)]

        # Overwrite the old data
        self.data.data = self.update_visuals(data)

        # Restore original range
        self.plot.x_range.start = min(data['x0']) - offset
        self.plot.x_range.end = max(data['x0']) + offset*2
        self.plot.y_range.start = min(data['y1']) - offset
        self.plot.y_range.end = max(data['y1']) + offset