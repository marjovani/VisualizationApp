from math import log

import networkx as nx
from bokeh.models import Circle, HoverTool, MultiLine
from bokeh.models.graphs import from_networkx, NodesAndLinkedEdges
from bokeh.palettes import Viridis256
from bokeh.plotting import figure

from dynamic_network.algorithms import dijkstra
from plots.custom_layouts import discrnd_layout
from plots.utils import interpolate_dict


class NodeLinkGraph:
    """
    This class manage all the functions/drawing and data
    of the Node-Link diagram
    """

    def __init__(self):
        """
        Initalize the plot
        """
        # Tooltips with node names and neighbors
        self.tooltips = [("Node", "@name")]

        # Contain style info about the graph
        self.data = {}

        # Setup plot
        self.plot = figure(plot_width=650, plot_height=650,
                           x_range=(-1.1, 1.1), y_range=(-1.1, 1.1))

        # Used to reset plot on each render
        self.default_render = self.plot.renderers.copy()

        # Default palette
        self.palette = Viridis256

        # Default parameters pygraphviz
        self.prog = 'sfdp'
        self.prog_attrs = "-Goverlap=prism"

    def update(self, dynamic_graph, timestamp, palette=None):
        """
        Draw the graph of the dynamic_graph for the given timestamp
        """
        # Get graphs for selected timestamp
        conn_graph = dynamic_graph.get_graph(timestamp)
        isol_graph = dynamic_graph.get_isolated_graph(timestamp)

        # Compute style attibutes
        self.__compute_colors(conn_graph, isol_graph, palette)
        self.__make_graph(conn_graph, isol_graph)

    def shortest_path(self, dynamic_graph, timestamp, source_node, target_node):
        """
        Compute the shortest path between 2 nodes
        """
        # Get graph
        conn_graph = dynamic_graph.get_graph(timestamp)
        isol_graph = dynamic_graph.get_isolated_graph(timestamp)

        # Compute shortest path
        path, _ = dijkstra(conn_graph, source_node, target_node)

        # Alpha values for nodes/edges
        self.data['node_alpha'] = {
            i: 0.25
            for i in conn_graph.nodes()
        }

        self.data['edge_alpha'] = {
            i: 0.25
            for i in self.data['edge_color']
        }

        # Alpha values for nodes in isolated graph
        for _, node_data in isol_graph.nodes(data=True):
            node_data['node_alpha'] = 0.25

        if path != []:
            # Previous node to keep track of the path
            prev_node = -1

            # Highlight shortest path
            for node in path:
                # Highlight node of the path
                self.data['node_alpha'][node] = 1

                # Highlight edge of the path
                if prev_node != -1:
                    self.data['edge_alpha'][(prev_node, node)] = 1

                prev_node = node

        self.__make_graph(conn_graph, isol_graph)

    def __compute_colors(self, conn_graph, isol_graph, palette=None):
        """
        Compute colors and size of the nodes/edges
        based on the weight/neighbors/hierarchy
        """
        # Node/Edge attibutes
        fields = ['neighbors', 'edge_color', 'edge_width', 'node_size']
        data = {field: {} for field in fields}

        # Check if palette was changed
        if palette is not None:
            self.palette = palette

        data['neighbors'] = {i: 0 for i in conn_graph.nodes()}

        # Add edges color
        for u, v, edge_data in conn_graph.edges(data=True):
            # Add edge color and thickness based on weight
            data['edge_color'][(u, v)] = log(edge_data['weight'])
            data['edge_width'][(u, v)] = log(edge_data['weight'])

            # Compute neighbors number for each node
            neighbors = conn_graph.neighbors(u)
            data['neighbors'][u] = sum(1 for _ in neighbors)

            neighbors = conn_graph.neighbors(v)
            data['neighbors'][v] = sum(1 for _ in neighbors)

        # if self.curr_metadata is not None:
        data['h_depth'] = {
            node[0]: node[1].get('h_depth', 0)
            for node in conn_graph.nodes(data=True)
        }

        # Interpolate values in new ranges
        data['edge_width'] = interpolate_dict(data['edge_width'], 1, 3)
        data['edge_color'] = interpolate_dict(data['edge_color'], 0, 255)
        data['node_size'] = interpolate_dict(data['neighbors'], 5, 20)

        # Check if h_depth have some value
        if max(data['h_depth'].values()) > 0:
            i = 'h_depth'
        else:
            i = 'neighbors'

        # Node color depends on h_depth if possible
        # neighbors number otherwise
        data['node_color'] = interpolate_dict(data[i], 0, 255)

        # Assign each color of the palette to nodes
        for node in data['node_color']:
            data['node_color'][node] = self.palette[int(
                data['node_color'][node])]

        for edge in data['edge_color']:
            data['edge_color'][edge] = self.palette[int(
                data['edge_color'][edge])]

        # Alpha values for nodes/edges
        data['node_alpha'] = {i: 1 for i in conn_graph.nodes()}
        data['edge_alpha'] = {i: 1 for i in data['edge_color']}

        # Alpha values for nodes in isolated graph
        for _, node_data in isol_graph.nodes(data=True):
            node_data['node_alpha'] = 1

        # Overwrite old graph style attributes
        self.data = data

    def __make_graph(self, conn_graph, isol_graph):
        """
        Create a nice looking layout using external libraries
        and add previously computed style
        """
        # Create a layout for the graph using PyGraphviz
        conn_layout = nx.nx_agraph.pygraphviz_layout(conn_graph,
                                                     prog=self.prog,
                                                     args=self.prog_attrs)

        # Compute new center of the plot
        max_pos = 0
        avg_pos = [0, 0]
        for node in conn_graph:
            avg_pos[0] += conn_layout[node][0]
            avg_pos[1] += conn_layout[node][1]

            # Get maximum distance from center
            if conn_layout[node][0] > max_pos:
                max_pos = conn_layout[node][0]
            if conn_layout[node][1] > max_pos:
                max_pos = conn_layout[node][1]

        # Some complex math
        avg_pos[0] /= len(conn_layout)
        avg_pos[1] /= len(conn_layout)
        max_pos /= 1.7

        # Assign all the colors and sizes to nodes and edges
        # Connected graph node attributes
        nx.set_node_attributes(conn_graph,
                               self.data['node_size'],
                               "node_size")

        nx.set_node_attributes(conn_graph,
                               self.data['node_color'],
                               "node_color")

        nx.set_node_attributes(conn_graph,
                               self.data['node_alpha'],
                               "node_alpha")

        # Connected graph edge attributes
        nx.set_edge_attributes(conn_graph,
                               self.data['edge_color'],
                               "edge_color")

        nx.set_edge_attributes(conn_graph,
                               self.data['edge_width'],
                               "edge_width")

        nx.set_edge_attributes(conn_graph,
                               self.data['edge_alpha'],
                               "edge_alpha")

        # Render center node-link graph
        conn_renderer = from_networkx(conn_graph, conn_layout)

        # Add circle for each node
        conn_renderer.node_renderer.glyph = Circle(line_alpha=0,
                                                   size="node_size",
                                                   fill_alpha="node_alpha",
                                                   fill_color="node_color")

        # Add lines for edges
        conn_renderer.edge_renderer.glyph = MultiLine(line_alpha="edge_alpha",
                                                      line_color="edge_color",
                                                      line_width="edge_width")

        # Selection policy for hover tool
        conn_renderer.inspection_policy = NodesAndLinkedEdges()

        # Hover highlight
        conn_renderer.node_renderer.hover_glyph = Circle(size=10,
                                                         line_alpha=0,
                                                         fill_color='#F9D02F')
        conn_renderer.edge_renderer.hover_glyph = MultiLine(line_width=5,
                                                            line_color='#4ADBA5')

        # Add node names
        conn_renderer.node_renderer.data_source.data['name'] = list(
            conn_graph.nodes())

        # Check if we have isolated nodes
        if isol_graph.nodes():
            # Render isolated nodes with a different layout
            isol_renderer = from_networkx(isol_graph,
                                          discrnd_layout,
                                          scale=int(max_pos),
                                          framesize=100,
                                          center=avg_pos)

            # Add circle for each node
            isol_renderer.node_renderer.glyph = Circle(size=8,
                                                       line_alpha=0,
                                                       fill_color="gray",
                                                       fill_alpha="node_alpha")

            # Selection policy for hover tool
            isol_renderer.selection_policy = NodesAndLinkedEdges()

            # Add names to tooltip
            isol_renderer.node_renderer.data_source.data['name'] = list(
                isol_graph.nodes())

        # ! Add arrows to edges but REALLY SLOW
        # from bokeh.models import Arrow, VeeHead
        # for edge in self.graph.edges_for_ts(ts):
        #     x1 = conn_layout[edge[0]][0]
        #     y1 = conn_layout[edge[0]][1]
        #     x2 = conn_layout[edge[1]][0]
        #     y2 = conn_layout[edge[1]][1]

        #     self.plot.add_layout(Arrow(end=VeeHead(size=6),
        #                                 x_start=x1, y_start=y1, x_end=x2, y_end=y2, line_alpha=0))

        # Change center
        self.plot.x_range.start = avg_pos[0] - max_pos
        self.plot.x_range.end = avg_pos[0] + max_pos
        self.plot.y_range.start = avg_pos[1] - max_pos
        self.plot.y_range.end = avg_pos[1] + max_pos

        # Reset plot to default
        self.plot.renderers = self.default_render

        # Add tooltips
        self.plot.add_tools(HoverTool(renderers=[conn_renderer],
                                      tooltips=self.tooltips))

        if isol_graph.nodes():
            # Add tooltips
            self.plot.add_tools(HoverTool(renderers=[isol_renderer],
                                          tooltips=self.tooltips))

            # Render isolated nodes
            self.plot.renderers.append(isol_renderer)

        # Render it
        self.plot.renderers.append(conn_renderer)
