from numpy import interp


def interpolate_dict(dictionary, min_range, max_range):
    """
    Interpolate values in dictionary to a new set of values
    (Don't modify the original dictionary)
    """
    work_dictionary = dictionary.copy()

    # Get max value in dictionary
    min_value = min(work_dictionary.values())
    max_value = max(work_dictionary.values())

    # Interpolate each value
    for key in work_dictionary:
        new_value = interp(work_dictionary[key],
                           [min_value, max_value],
                           [min_range, max_range])

        # Assign the new value to the dictionary
        work_dictionary[key] = new_value

    return work_dictionary


def interpolate_array(array, min_range, max_range):
    """
    Interpolate values in an arrau to a new set of values
    (Don't modify the original array)
    """
    work_array = array.copy()

    # Get max value in dictionary
    min_value = min(work_array)
    max_value = max(work_array)

    # Interpolate each value
    for i, value in enumerate(work_array):
        new_value = interp(value,
                           [min_value, max_value],
                           [min_range, max_range])

        # Assign the new value to the dictionary
        work_array[i] = new_value

    return work_array