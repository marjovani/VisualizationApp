import random
from math import log, sqrt

from bokeh.models import ColumnDataSource
from bokeh.palettes import Inferno256
from bokeh.plotting import figure
import networkx as nx
from dynamic_network.aggregator import Aggregator

from plots.utils import interpolate_array


class AdjacencyMatrix:
    """
    This class manage all the functions/drawing and data
    of the adjacency matrix plot
    """

    def __init__(self):
        # Rectangles data to be displayed in the matrix plot
        self.data = ColumnDataSource(data=dict(x=[], y=[],
                                               colors=[],
                                               alphas=[]))

        # Adjacency matrix plot object
        self.plot = figure(plot_width=650, plot_height=650,
                           x_range=(-1, 1), y_range=(-1, 1))

        # Rectangles will be displayed on change of self.data
        self.plot.rect("x", "y", color="colors", width=5, height=5,
                       alpha="alphas", source=self.data)

        # Default palette
        self.palette = Inferno256

    def update(self, agg_graph):
        """
        Given a dynamic_graph instance aggregated over time,
        parse it and display the edges weight
        """
        # Source data structure
        fields = ['x', 'y', 'colors', 'alphas']
        data = {field: [] for field in fields}
        scaled_weights = []

        for start_node, end_node, edge_data in agg_graph.edges(data=True):
            data['x'].append(start_node)
            data['y'].append(end_node)
            data['alphas'].append(1)
            scaled_weights.append(log(edge_data['weight']))

        # Interpolate set of weight in colors
        data['colors'] = interpolate_array(scaled_weights, 0, 255)

        for i, value in enumerate(data['colors']):
            data['colors'][i] = self.palette[int(value)]

        self.data.data = data

        # Set ranges
        self.plot.x_range.start = 0
        self.plot.x_range.end = max(data['x'])
        self.plot.y_range.start = 0
        self.plot.y_range.end = max(data['y'])

    def update_palette(self, new_palette):
        """
        Update the palette of the adjacency matrix
        """
        data = self.data.data.copy()

        # Interpolate set of weight in colors
        for i, value in enumerate(data['colors']):
            index = self.palette.index(value)
            data['colors'][i] = new_palette[index]

        self.palette = new_palette
        self.data.data = data

    def node_filter(self, agg_graph, node_ranges):
        """
        Filter out the nodes that are not in node_ranges
        """
        data = self.data.data.copy()

        node = 0
        previous_range = []

        for start_node, end_node in agg_graph.edges():
             # If weight is in the range show it
            for node_range in node_ranges:
                if start_node in node_range and end_node in node_range:
                    data['alphas'][node] = 1
                    previous_range.append(node)
                elif node in previous_range:
                    pass
                else:
                    data['alphas'][node] = 0

            node += 1

        self.data.data = data

    def order(self, agg_graph):
        # Wanted clusters
        k = 45
        # Create clusters base stucture
        clusters = {}
        for index in agg_graph.nodes():
            clusters[index] = [index]

        # Compute all shortest paths of each pair of nodes
        sp = dict(nx.all_pairs_shortest_path_length(agg_graph))

        # Compute the maximum distance length between nodes
        max_length = 0
        for key1 in sp:
            for key2 in sp[key1]:
                max_length = max(max_length, sp[key1][key2])
        max_length += 1

        # Remove self loops
        for node in sp:
            sp[node].pop(node)

        # Number of clusters
        lc = len(clusters)

        # While number of clusters is bigger that wanted
        while lc > k:
            min_dist = max_length
            min_source = -1
            min_target = -1

            # Search shortest path in the collection of pairs
            for source in sp:
                for target in sp[source]:
                    distance = sp[source][target]

                    # Check min distance
                    if distance < min_dist:
                        min_dist = distance
                        min_source = source
                        min_target = target

            # If no path has been found, then all clusters are isolated. Exit.
            if min_source == -1:
                break

            # Remove that path
            sp[min_source].pop(min_target)

            # Copy all connected nodes from target to source
            for value in clusters[min_target]:
                clusters[min_source].append(value)

            # Empty target connected nodes
            clusters[min_target] = []

            # Check clusters number
            lc = len(clusters)
            for cluster in clusters.values():
                if cluster == []:
                    lc -= 1

        # Change x, y squares position for ordered drawing
        mapping = {}
        num = 0
        for cluster in clusters.values():
            for node in cluster:
                print(node)
                mapping[node] = num
                num += 1

        x_data = []
        for coord in self.data.data['x']:
            x_data.append(mapping[coord])
        self.data.data['x'] = x_data
        y_data = []
        for coord in self.data.data['y']:
            y_data.append(mapping[coord])
        self.data.data['y'] = y_data

    def reset_filters(self, graph):
        """
        Reset all filters
        """
        data['alphas'] = [1 for _ in data['alphas']]

        aggregator = Aggregator()
        agg_graph = aggregator.agg_time(graph.graphs,
                                             graph.min_ts,
                                             graph.max_ts)
        self.update(agg_graph)
