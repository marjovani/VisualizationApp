bokeh serve --dev --log-level debug .
