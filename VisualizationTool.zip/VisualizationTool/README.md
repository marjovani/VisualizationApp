# A lightweight tool to visualize Dynamic Networks #

<div>
    <img style="width: 39%;" src="docs/interim_src/images/GUI2.png">
    <img style="width: 25%;" src="docs/interim_src/images/Nodelink.png">
    <img style="width: 25%;" src="docs/interim_src/images/Nodelink2.png">
</div>

The application renders data,
formatted as a dynamic network, into several visualizations, and
provides an interactive environment that the user can adjust to his/her
wishes.

## Run ##

You can open the Visualization tool using inside the directory:

    $ bokeh serve --show .

## Requirements ##

To run the script on your system you need to have a python3 environment installed. Make sure the commands `python3` and `pip` (`pip3` on some systems) work.

Steps:

1) Make sure you have Python3 installed:
    ```bash
    # apt install python3 python3-dev python3-pip
    ```

2) Install Graphviz:
    ```bash
    # apt install graphviz graphviz-dev
    ```

3) Finally, install the required modules:
    ```bash
    # pip install -r requirements.txt
    ```
