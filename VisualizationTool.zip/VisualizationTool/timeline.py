from bokeh.models import ColumnDataSource
from bokeh.plotting import figure

from algorithms import dijkstra


class Timeline:
    """
    This class manage all the functions/drawing and data
    of the timeline plot
    """

    def __init__(self):
        """
        Initalize the plot and data
        """
        # Segments data to be displayed in the timeline plot
        self.data = ColumnDataSource(data=dict(x0=[], y0=[],
                                                      x1=[], y1=[],
                                                      widths=[],
                                                      alphas=[],
                                                      colors=[]))

        # The actual timeline plot object
        self.plot = figure(plot_width=1300, plot_height=450,
                           x_range=(-1, 1), y_range=(-1, 1))

        # The segments to be displayed when self.timeline_data is changed
        self.plot.segment("x0", "y0", "x1", "y1", line_width="widths",
                          line_color="colors", line_alpha="alphas",
                          source=self.data)

    def update(self, dynamic_graph, offset=50):
        """
        Given a dynamic_graph instance, parse it and display
        the edges of all timestamps
        """
        # Source data structure
        fields = ['x0', 'y0', 'x1', 'y1', 'colors', 'alphas', 'widths']
        data = {field: [] for field in fields}

        # For each graph
        for ts in dynamic_graph.graphs:
            # For each edge
            for u, v in dynamic_graph.edges_for_ts(ts):
                # Segment coordinates
                data['x0'].append(ts)
                data['y0'].append(u)
                data['x1'].append(ts+offset)
                data['y1'].append(v)

                # Segment properties
                data['colors'].append("#0099FF")
                data['alphas'].append(1)
                data['widths'].append(1)

        # Update the data source for the timeline
        self.data.data = data

        # Update the ranges of the plot
        self.plot.x_range.start = -offset
        self.plot.x_range.end = max(data['x0']) + offset*2
        self.plot.y_range.start = -offset
        self.plot.y_range.end = max(data['y1']) + offset

    def timestamp_filter(self, dynamic_graph, min_ts, max_ts):
        """
        Filter out the edges outside the range (min_ts, max_ts) of timestamps
        """
        # Copy the data to be modified
        data = self.data.data.copy()

        # Node-timestamp reference
        node = 0

        # For each graph
        for ts in dynamic_graph.graphs:
            # For each edge
            for _, _ in dynamic_graph.edges_for_ts(ts):
                # If weight is in the range show it
                if min_ts <= ts <= max_ts:
                    data['alphas'][node] = 1
                else:
                    data['alphas'][node] = 0

                # Increment reference
                node += 1

        # Update the data source for the timeline
        self.data.data = data

    def edge_weight_filter(self, dynamic_graph, min_weight, max_weight):
        """
        Filter out the edges outside the range (min_weight, max_weight)
        """
        # Copy the data to be modified
        data = self.data.data.copy()

        # Node-timestamp reference
        node = 0

        # For each graph
        for ts in dynamic_graph.graphs:
            # For each edge
            for _, _, edge_data in dynamic_graph.edges_for_ts(ts, data=True):
                # If weight is in the range show it
                if min_weight <= edge_data['weight'] <= max_weight:
                    data['alphas'][node] = 1
                else:
                    data['alphas'][node] = 0

                # Increment reference
                node += 1

        # Update the data source for the timeline
        self.data.data = data

    def node_filter(self, dynamic_graph, node_ranges):
        """
        Filter out the nodes that are not in the defined set of ranges
        """
        # Copy the data to be modified
        data = self.data.data.copy()

        # Node-timestamp reference
        node = 0

        previous_range = []

        # For each graph
        for ts in dynamic_graph.graphs:
            # For each edge
            for start_node, end_node in dynamic_graph.edges_for_ts(ts):
                # If weight is in the range show it
                for node_range in node_ranges:
                    if start_node in node_range and end_node in node_range:
                        data['alphas'][node] = 1
                        previous_range.append(node)
                    elif node in previous_range:
                        pass
                    else:
                        data['alphas'][node] = 0

                # Increment reference
                node += 1

        # Update the data source for the timeline
        self.data.data = data

    def shortest_path(self, dynamic_graph, source_node, target_node):
        """
        Compute the shortest path between source_node and target_node and
        display it on the plot
        """
        # Copy the data to be modified
        data = self.data.data.copy()

        # Color all the edges like `no in shortest path`
        data['colors'] = ["grey" for _ in data['colors']]
        data['alphas'] = [0.5 for _ in data['alphas']]
        data['widths'] = [0.5 for _ in data['widths']]

        # Node-timestamp reference
        node = 0

        # For each graph
        for ts in dynamic_graph.graphs:
            # Compute shortest path using Dijkstra algorithm
            path, _ = dijkstra(dynamic_graph.get_graph(ts),
                               source_node,
                               target_node)

            # If a path exists between source_node and target_node
            if path != []:
                # For each edge in given timestamp
                for u, v in dynamic_graph.edges_for_ts(ts):
                    # If edge is in path
                    if (u in path) and (v in path):
                        # Highlight edge
                        data['colors'][node] = "red"
                        data['alphas'][node] = 1
                        data['widths'][node] = 4

                    # Increment node
                    node += 1
            else:
                # Increment node by nodes skipped in this timestamp
                node += len(dynamic_graph.edges_for_ts(ts))

        # Replce old data
        self.data.data = data

    def reset_filters(self):
        """
        Reset all filters
        """
        # Copy the data to be modified
        data = self.data.data.copy()

        data['colors'] = ["#0099FF" for _ in data['colors']]
        data['alphas'] = [1 for _ in data['alphas']]
        data['widths'] = [1 for _ in data['widths']]

        self.data.data = data
