import os
from io import BytesIO
from base64 import b64decode

from bokeh.io import curdoc
from bokeh.layouts import column, gridplot, layout, row, widgetbox
from bokeh.models import ColumnDataSource, CustomJS, Slider
from bokeh.models.widgets import Button, CheckboxButtonGroup, Dropdown, Div, Select
from bokeh.plotting import figure

from utils import load_dialog


class BaseGUI:
    # Page title
    title = "VTG41"

    # Path to logo image
    logo_path = "/VisualizationTool/static/logo.png"

    # Grid of plots
    grid = None

    # Top row of widgets
    top_widgetbox = None

    # Left column of widgets
    left_widgetbox = None

    # Right column of widgets
    right_widgetbox = None

    # Currently open files
    curr_dataset = None
    curr_metadata = None

    # Where we store our datasets
    dataset_store = os.path.dirname(os.path.realpath(__file__)) + "/data/datasets/"
    metadata_store = os.path.dirname(os.path.realpath(__file__)) + "/data/hierarchies/"

    def __init__(self):
        """
        BaseGUI Constructor
        """
        self.draw()

    def draw(self):
        """
        Draw the page with some example data and widgets
        Default layout:
            IMG===WIDGETS=============
            WIDGETS==PLOTGRID==WIDGETS
        """
        # Clear any previous draw
        curdoc().clear()

        # Set page title
        curdoc().title = self.title

        # Setup widgets
        self.setup_top_widgetbox()
        self.setup_left_widgetbox()
        self.setup_right_widgetbox()

        # Setup plot grid
        self.setup_grid()

        # Create logo div
        logo_image = "<img src=" + self.logo_path + " style='width:250px'/>"
        logo = Div(text=logo_image, width=300)

        # Compose pieces of layout
        left_col = column(self.left_widgetbox)
        right_col = column(self.right_widgetbox)
        upper_row = row(logo, self.top_widgetbox)
        lower_row = row(left_col, self.grid, right_col)

        # Create page layout
        page_layout = layout([[upper_row], [lower_row]],
                             sizing_mode='scale_width')

        # Show the page
        curdoc().add_root(page_layout)

    def setup_left_widgetbox(self):
        """
        Init some example widgets for the left column
        Override this method with your own widgets
        """
        # Setup widgets
        button0 = Button(label="Button", button_type="warning")
        button1 = Button(label="Button", button_type="primary")
        checkbox = CheckboxButtonGroup(labels=["Option 1", "Option 2", "Option 3"],
                                       active=[0, 1])
        select = Select(title="Option:", value="foo",
                        options=["foo", "bar", "baz", "quux"])
        freq = Slider(title="frequency", value=1, start=1, end=500, step=1)

        # Place them in left column
        self.left_widgetbox = widgetbox(button0,
                                        button1,
                                        checkbox,
                                        select,
                                        freq)

    def setup_right_widgetbox(self):
        """
        Init some example widgets for the left column
        Override this method with your own widgets
        """
        # Setup more widgets
        button2 = Button(label="Button", button_type="warning")
        button3 = Button(label="Button", button_type="primary")
        button4 = Button(label="Button", button_type="danger")

        # Place them in left column
        self.right_widgetbox = widgetbox(button2,
                                         button3,
                                         button4)

    def setup_top_widgetbox(self):
        """
        Init some example widgets for the left column
        Override this method with your own widgets
        """
        # Setup dataset selection widget
        upload_dataset = Button(
            label="Add Dataset File", button_type="success")
        upload_metadata = Button(
            label="Add Metadata File", button_type="danger")

        # List of files
        menu = [(file[:-4], file) for file in os.listdir(self.dataset_store)]
        if self.curr_dataset is None:
            dataset_dropdown = Dropdown(
                label="Select dataset", button_type="primary", menu=menu)
        else:
            dataset_dropdown = Dropdown(
                label=self.curr_dataset[:-4], button_type="primary", menu=menu)

        menu = [(file[:-4], file) for file in os.listdir(self.metadata_store)]
        if self.curr_metadata is None:
            metadata_dropdown = Dropdown(
                label="Select metadata", button_type="warning", menu=menu)
        else:
            metadata_dropdown = Dropdown(
                label=self.curr_metadata[:-4], button_type="warning", menu=menu)

        # Place widgets in top row
        self.top_widgetbox = row(upload_dataset,
                                 dataset_dropdown,
                                 upload_metadata,
                                 metadata_dropdown)

        # Selected data
        dataset_source = ColumnDataSource(
            {'file_name': [], 'file_contents': []})
        metadata_source = ColumnDataSource(
            {'file_name': [], 'file_contents': []})

        # Link callback functions to changes in widgets
        dataset_source.on_change('data', self.open_dataset_button_callback)
        dataset_dropdown.on_change(
            'value', self.open_dataset_selection_callback)

        metadata_source.on_change('data', self.open_metadata_button_callback)
        metadata_dropdown.on_change(
            'value', self.open_metadata_selection_callback)

        # JavaScript: Open File Dialog
        upload_dataset.callback = CustomJS(
            args=dict(file_source=dataset_source), code=load_dialog)
        upload_metadata.callback = CustomJS(
            args=dict(file_source=metadata_source), code=load_dialog)

    def setup_empty_grid(self):
        """
        Setup the plot grid with empty plots
        """
        p1 = figure(plot_width=1300, plot_height=450, title=None)
        p2 = figure(plot_width=650, plot_height=450, title=None)
        p3 = figure(plot_width=650, plot_height=450, title=None)

        # Place plots in grid
        self.grid = gridplot([[p1], [p2, p3]])

    def setup_grid(self):
        """
        Setup the plot grid with empty plots
        Override this method with your own
        """
        self.setup_empty_grid()

    # Callback function for when a new dataset is uploaded
    def open_dataset_button_callback(self, attr, old, new):
        # Get file name
        self.curr_dataset = new['file_name'][0]

        # Parse and save the contents
        self.parse_and_save(new['file_contents'][0],
                            self.dataset_store + self.curr_dataset)

        # Reload GUI
        self.draw()

    # Callback function for when a new dataset is uploaded
    def open_metadata_button_callback(self, attr, old, new):
        # Get file name
        self.curr_metadata = new['file_name'][0]

        # Parse and save the contents
        self.parse_and_save(new['file_contents'][0],
                            self.metadata_store + self.curr_metadata)

        # Reload GUI
        self.draw()

    # Callback function when a new dataset is selected
    def open_dataset_selection_callback(self, attr, old, new):
        self.curr_dataset = new
        self.draw()

    # Callback function when a new dataset is selected
    def open_metadata_selection_callback(self, attr, old, new):
        self.curr_metadata = new
        self.draw()

    def parse_and_save(self, raw_content, file):
        """
        Parse the content from JS and save it to file
        """
        with open(file, "w") as f:
            # Remove the prefix that JS adds
            b64_contents = raw_content.split(",")[1]

            # Read and parse data from HTML to string
            file_contents = b64decode(b64_contents)
            file_io = BytesIO(file_contents)
            df = file_io.read()
            content = df.decode('UTF-8')

            # Write file on server, in /data/datasets
            f.write(content)
