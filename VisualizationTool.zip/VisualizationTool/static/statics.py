import os

# Absolute path to project directory
base_abs_dir = os.path.abspath(".")
base_dir = base_abs_dir.split("/")[-1]

# Path to logo image
logo_img = base_dir + "/static/logo.png"

# Legends images path
infero_palette = base_dir + "/static/inferno_palette.png"
viridis_palette = base_dir + "/static/viridis_palette.png"
cividis_palette = base_dir + "/static/cividis_palette.png"
greys_palette = base_dir + "/static/greys_palette.png"