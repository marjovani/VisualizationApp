from gui import GUI

gui = GUI()
gui.draw()