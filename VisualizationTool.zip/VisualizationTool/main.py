from gui.gui import GUI

gui = GUI()
gui.draw()
# gui.debug_load(dataset=True, metadata=True)
