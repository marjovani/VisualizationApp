from gui.gui import GUI

gui = GUI()
gui.draw()