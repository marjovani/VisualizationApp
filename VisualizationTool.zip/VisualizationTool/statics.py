# Legends images path
infero_palette = "/VisualizationTool/static/inferno_palette.png"
viridis_palette = "/VisualizationTool/static/viridis_palette.png"
cividis_palette = "/VisualizationTool/static/cividis_palette.png"
greys_palette = "/VisualizationTool/static/greys_palette.png"