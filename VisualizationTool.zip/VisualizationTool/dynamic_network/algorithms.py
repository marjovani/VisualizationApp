def dijkstra(graph, source, target):
    # Contains vertices that create the path from source to target
    path = []

    # Define dictionaries to store the data
    # Stores the nodes (as keys) and the shortest distance (as values) that still have to be visited
    Q = {}
    # Stores the predecessor of a node
    pred = {}
    # Stores the shortest distance; also needed because we need these values stored permanently
    shortest = {}

    # Check if nodes are in the graph
    if source in graph.nodes() and target in graph.nodes():
        # Special case where source and target are the same node
        if target == source:
            path.append(source)
            return path, 0
        # Source and target are different nodes
        else:
            # Setup dicts
            for v in graph.nodes():
                Q[v] = shortest[v] = float("inf")
                pred[v] = None

            Q[source] = 0
            shortest[source] = 0

            # Start searching the shortest path
            while Q and min(Q.values()) != float("inf"):
                # Find the vertex u in Q with the lowest value shortest[u] and remove it from Q
                u = min(Q, key=Q.get)
                del Q[u]

                if u != target:
                    for v in graph.successors(u):
                        if shortest[u] + graph[u][v]['weight'] < shortest[v]:
                            shortest[v] = shortest[u] + graph[u][v]['weight']
                            Q[v] = shortest[v]
                            pred[v] = u

            if shortest[target] != float("inf"):
                u = target
                path.append(u)
                while u != source:
                    u = pred[u]
                    path.append(u)

                return list(reversed(path)), shortest[target]
            else:
                return path, float("inf")

    else:
        return path, float("inf")

# Implemented in GUI
#   def drawPath(graph, timss, timsss, x, y, colors, alphas, width, source, target):
#       """
#       drawPath takes as parameters all the required data in order to plot a segment
#       result: shortest path between source and target will be RED, in each timestamp
#               other edges will be GREY and much thinner
#       obs: could be inneficient if the path is long because of how it deals with
#           the coulumndatasource...
#       """
#       for ts in graph.graphs:
#           path, weight = dijkstra(graph.graphs[ts], source, target)
#           # print(ts, path)
#           if len(path) > 1:
#               for i in range(0, len(path) - 1):
#                   for k in range(0, len(timss)):
#                       if(timss[k] == ts and x[k] == path[i] and y[k] == path[i+1]):
#                           colors[k] = "red"
#                           width[k] = 4
#                           alphas[k] = 1
#                       elif timss[k] == ts and colors[k] == "#ffdab9":
#                           colors[k] = "grey"
#                           alphas[k] = 0.5
#                           width[k] = 0.05
#           elif len(path) == 1:
#               for k in range(0, len(timss)):
#                   if(timss[k] == ts and x[k] == path[0] and y[k] == path[0]):
#                       colors[k] = "#ffdab9"
#                   elif timss[k] == ts:
#                       colors[k] = "grey"
#                       alphas[k] = 0.5
#                       width[k] = 0.05
#           else:
#               for k in range(0, len(timss)):
#                   if timss[k] == ts:
#                       colors[k] = "grey"
#                       alphas[k] = 0.5
#                       width[k] = 0.05
#       return timss, timsss, x, y, colors, alphas, width


# Matrix counts the number of occurences of a certain edge in the shortest path, considering each timestamp
def shortestPathMatrix(graph, max_timestamp, max_node, source, target):
    # Create a matrix, fill it with 0s
    n = max_node + 1
    matrix = [[0] * n for i in range(n)]

    # Apply Dijkstra for every valid timestamp, "remember" the edges that appear in the shortest path
    for ts in range(0, max_timestamp+1):
        if ts in graph.graphs:
            path, _ = dijkstra(graph.graphs[ts], source, target)
            # DEBUG: print (ts, path)

            if len(path) > 1:
                for i in range(0, len(path) - 1):
                    matrix[path[i]][path[i+1]] += 1
            elif len(path) == 1:
                matrix[path[0]][path[0]] += 1

    # Print the matrix
    for i in range(0, n):
        for j in range(0, n):
            print(matrix[i][j], end=' ')
        print()
