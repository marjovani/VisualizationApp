import os

import matplotlib.pyplot as plt
import networkx as nx

from dynamic_network.parse import parse_row


class DynamicGraph:

    def __init__(self, data_file, metadata_file=None):
        """
        Constructor function

        Params:
        data_file: dynamic graph file to be parsed
        metadata_file (optional): metadata file for the graph
        """
        # Store a graph for each timestamp
        self.graphs = {}

        # Store all the nodes that are not connected (in each timestamp)
        self.isolated_graphs = {}

        # Store filenames for later user
        self.data_file = data_file
        self.metadata_file = metadata_file

        # Get number of lines in hierarchy file (if possible)
        if metadata_file is not None:
            self.nodes_num = sum(1 for line in open(metadata_file))

        # Min/max timestamp
        self.min_ts = 0
        self.max_ts = 0

        # Min/max weight
        self.min_weight = 0
        self.max_weight = 0

        # Max hierarchy depth
        self.h_max = 0

        # Number of edges in the graph
        self.total_edges = 0

        # Valid timestamps
        self.valid_timestamps = []

    def load_metadata_file(self, metadata_file):
        """
        Load and parse metadata previously missing
        """
        # Parse total number of nodes
        self.nodes_num = sum(1 for line in open(metadata_file))
        self.metadata_file = metadata_file

        # For each timestamp
        for ts in self.graphs:
            # Fill the graph with all nodes
            self.isolated_graphs[ts].add_nodes_from(
                [i for i in range(1, self.nodes_num)])

            # Check which nodes are connected
            connected_nodes = self.graphs[ts].nodes()

            # Remove that nodes from the isolated graph
            self.isolated_graphs[ts].remove_nodes_from(connected_nodes)

        # Hierarchy level of each node
        with open(self.metadata_file, "r") as f:
            h_depth = [row.count("/") for row in f.readlines()]

        # Deepest tree of directories
        self.h_max = max(h_depth)

        # For each timestamp
        for ts in self.graphs:
            # For each node in graph
            for node in self.graphs[ts].nodes():
                # Save info about hierarchy level
                self.graphs[ts].node[node]['h_depth'] = h_depth[node-1]

            # For each node in the isolated graph
            for node in self.isolated_graphs[ts].nodes():
                # Save info about hierarchy level
                self.isolated_graphs[ts].node[node]['h_depth'] = h_depth[node-1]

    def make_graph(self):
        """
        Parse the stored datafile and
        create a graph for each timestamp
        """
        weights = []
        timestamps = []

        # Open file (context manager)
        with open(self.data_file, "r") as f:
            # Start reading
            for row in f.readlines():
                # Parse the result
                result = parse_row(row)

                if result is not None:
                    # Split the results in
                    # ts = timestamp
                    # u = first edge
                    # v = second edge
                    # w = weight
                    ts, u, v, w = result

                    # Check if we already have an instance for given timestamp
                    if ts not in self.graphs:
                        # Create the main graph
                        self.graphs[ts] = nx.DiGraph(
                            name="Timestamp {0}".format(ts))
                        self.isolated_graphs[ts] = nx.DiGraph(
                            name="Timestamp {0}".format(ts))

                        # If we have metadata create the isolated nodes graph
                        if self.metadata_file is not None:
                            self.isolated_graphs[ts].add_nodes_from(
                                [(i, dict(name=i)) for i in range(1, self.nodes_num)])

                    # Append new edge
                    self.graphs[ts].add_node(u, name=u)
                    self.graphs[ts].add_node(v, name=v)
                    self.graphs[ts].add_edge(u, v, weight=w)

                    # Store values for later stats
                    weights.append(w)
                    timestamps.append(ts)

                    # Count edges
                    self.total_edges += 1

                    # If we have a metadafile where can get the info
                    if self.metadata_file is not None:
                        # If u is still in isolated graph, remove it
                        if u in self.isolated_graphs[ts].nodes():
                            self.isolated_graphs[ts].remove_node(u)

                        # If v is still in isolated graph, remove it
                        if v in self.isolated_graphs[ts].nodes():
                            self.isolated_graphs[ts].remove_node(v)

                    # Add timestamp to valid collection
                    self.valid_timestamps.append(ts)

            # Update stats about the graph
            # Weight stats
            self.min_weight = min(weights)
            self.max_weight = max(weights)

            # Timestamp stats
            self.min_ts = min(timestamps)
            self.max_ts = max(timestamps)

            # Check if something was done
            if self.graphs == {}:
                raise ValueError("Empty graph - File not in right format")

    def info(self):
        """
        Return info about the graph in an HTML usable format
        """
        if self.graphs != {}:
            self.nodes_num = self.compute_num_nodes()
            info = "<ul><li>Number of timestamps: {0}</li>"\
                   "<li>Number of nodes: {1}</li>"\
                   "<li>Number of edges: {2}</li></ul>".format(len(self.graphs.keys()),
                                                               self.nodes_num,
                                                               self.total_edges)
        else:
            info = "No data"

        return info

    def get_isolated_graph(self, ts):
        """
        Return the graph of nodes that are not connected
        (parsed from metadata file)
        """
        return self.isolated_graphs[ts]

    def is_valid_ts(self, ts):
        """
        Easy check if a timestamp exists in dynamic graph
        """
        return ts in self.valid_timestamps

    def compute_num_nodes(self):
        """
        Compute the number of nodes based
        on the one present already in the graphs
        """
        node_list = {}

        for ts in self.graphs:
            for node in self.nodes_for_ts(ts):
                node_list.update({node: 1})

        return len(node_list.keys())

    def get_graph(self, ts):
        """
        Access method for cleaner code
        """
        return self.graphs[ts]

    def nodes_for_ts(self, ts):
        """
        Access method for cleaner code
        """
        return self.graphs[ts].nodes()

    def edges_for_ts(self, ts, data=False):
        """
        Access method for cleaner code
        """
        return self.graphs[ts].edges(data=data)

    def neighbors_for_ts(self, node, ts):
        """
        Access method for cleaner code
        """
        return self.graphs[ts].neighbors(node)
