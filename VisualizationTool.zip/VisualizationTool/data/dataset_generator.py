import random

# Get number of timestamps and nodes from user
num_ts = int(input("Num of timestamps: "))
num_nodes = int(input("Num of nodes: "))

# Probability that a node appears in the timestamp
prob_node = float(input("Probability node in timestamp [0-1]: "))

# Probability that a node is connected to another
prob_edge = float(input("Probability node connected [0-1]: "))

filename = "dataset_{0}ts_{1}n.txt".format(num_ts, num_nodes)

with open(filename, "w") as f:
    text = ["time start target weight\n\n"]

    # For each timestamp
    for ts in range(num_ts):
        # For each node
        for node in range(num_nodes):
            if random.random() < prob_node:
                # Random number of edges for the node
                num_edges = random.randint(0, num_nodes)

                # For each edge from the node
                for edge in range(num_edges):
                    if random.random() < prob_edge:
                        # Random edge weight
                        weight = random.randint(1000, 10000)
                        text.append("{0} {1} {2} {3}\n".format(ts,
                                                               node,
                                                               edge,
                                                               weight))

    # Write the new dataset
    f.writelines(text)
