from bokeh.models import ColumnDataSource, CustomJS
from numpy import interp


def interpolate_dict(dictionary, min_range, max_range):
    """
    Interpolate values in dictionary to a new set of values
    (Don't modify the original dictionary)
    """
    work_dictionary = dictionary.copy()

    # Get max value in dictionary
    min_value = min(work_dictionary.values())
    max_value = max(work_dictionary.values())

    # Interpolate each value
    for key in work_dictionary:
        new_value = interp(work_dictionary[key],
                           [min_value, max_value],
                           [min_range, max_range])

        # Assign the new value to the dictionary
        work_dictionary[key] = new_value

    return work_dictionary


def interpolate_array(array, min_range, max_range):
    """
    Interpolate values in an arrau to a new set of values
    (Don't modify the original array)
    """
    word_array = array.copy()

    # Get max value in dictionary
    min_value = min(word_array)
    max_value = max(word_array)

    # Interpolate each value
    for i, value in enumerate(word_array):
        new_value = interp(value,
                           [min_value, max_value],
                           [min_range, max_range])

        # Assign the new value to the dictionary
        word_array[i] = new_value

    return word_array


def on_change(widget, callback):
    """
    Custom on_change which support correctly
    the `mouseup` callback_policy
    """
    source = ColumnDataSource(data=dict(value=[]))
    source.on_change('data', callback)

    widget.callback = CustomJS(args=dict(source=source), code="""
        source.data = { value: [cb_obj.value] }
    """)


# Custom JS to load files
load_dialog = """
    function read_file(filename) {
        var reader = new FileReader();
        reader.onload = load_handler;
        reader.onerror = error_handler;
        reader.readAsDataURL(filename);
    }

    function load_handler(event) {
        var b64string = event.target.result;
        file_source.data = {'file_contents' : [b64string], 'file_name':[input.files[0].name]};
        file_source.trigger("change");
    }

    function error_handler(evt) {
        if(evt.target.error.name == "NotReadableError")
            alert("Can't read file!");
    }

    var input = document.createElement('input');
    input.setAttribute('type', 'file');
    input.onchange = function(){
        if (window.FileReader)
            read_file(input.files[0]);
        else
            alert('FileReader is not supported in this browser');
    }

    input.click();
"""
