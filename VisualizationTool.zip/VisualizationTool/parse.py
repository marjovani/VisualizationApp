import re


def parse_row(row):
    """
    Function parse a row if in format:
    `1234 1234 1234 1234`
    4 numbers in single row

    If the row is in this format then
    returns a list of same values casted to
    integers. None otherwise.
    """
    # Return value
    rv = None

    # Use a regular expression to filter rows
    # p = 4 numbers divided by spaces
    p = "([0-9])+ ([0-9])+ ([0-9])+ ([0-9])+"
    pattern = re.compile(p)

    # If row match pattern
    if pattern.match(row):
        # Split row in a tuple and cast values to int
        rv = list(map(int, row.split()))

    return rv
